%% Watershed Model - System of Systems - Input Data
% Developer: Marcus Nobrega Gomes Junior
% 4/12/2021
% Input Data
% This function develops the information regarding the V-Tilted Catchment

function [DEM,n,h_0,ksat,dtheta,I_0,psi,d_0,Delta_x,Delta_y] = gridded()
% Cell Resolution
Delta_x = 20;
Delta_y = 20;
v_tilted % V-tilted parameters

end