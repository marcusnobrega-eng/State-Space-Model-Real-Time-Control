%% Symbolic Jacobian Matrices
% 4/26/2021
% Developer: Marcus Nobrega
% Goal - Define symbolic jacobian matrices for a given system of equations
% Last Editted: 11/08/2021
function [alfa_1_function,alfa_2_function,beta_1_function,beta_2_function] = symbolic_jacobians()
    syms Qin Kot u h hout Kst hsp
    [Area_Function] = reservoir_area(0);
    % Phase 1 (h < hs)
    h_dot_eq =  (1/sym(Area_Function)).*(Qin - (Kot.*u.*sqrt(h - hout)));
    alfa_1 = jacobian(h_dot_eq,h);
    beta_1 = jacobian(h_dot_eq,u);
    % Phase 2 (h >= hs)
    h_dot_eq =  (1/sym(Area_Function)).*(Qin - Kot.*u.*sqrt(h - hout)  -(Kst.*((h - hsp)^(3/2))));
    alfa_2 = jacobian(h_dot_eq,h);
    beta_2 = jacobian(h_dot_eq,u);
    % Functions
    alfa_1_function = matlabFunction(alfa_1);
    alfa_2_function = matlabFunction(alfa_2);
    beta_1_function = matlabFunction(beta_1);
    beta_2_function = matlabFunction(beta_2);
end