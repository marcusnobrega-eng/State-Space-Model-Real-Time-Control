%% System (Cathcment + Reservoir + Channel) Graphs - Linearized Model
out_c = outflow(h_c(:,segments),x_cells(segments),roughness(segments),B_slope(segments));
channel_depths = h_c';
set(gcf,'units','inches','position',[5,0,7,12])
time_plot = [0:time_step:(n_steps-1)*time_step]/60; % min
subplot(4,3,[7:9])
plot(time_plot,out_c,'red','LineWidth',2.5)
hold on
plot(time_plot,out_r_plot,'blue','LineWidth',2.5)
hold on
plot(time_plot,out_w,'green','LineWidth',2.5)
set(gca,'FontSize',12)
xlabel('Time (min)','FontSize',12); ylabel('Flow cms','FontSize',12);
legend('o^c','o^{r}','o^w')
% Surf
subplot(4,3,[1:6])
Y = [1:segments]'.*y_cells;
X = time_plot';
z = surf(X,Y,channel_depths)
set(z,'LineStyle','none')
set(gca,'Ydir','reverse','FontSize',12)
ylim([1 max(Y)])
xlim([0 max(time_plot)])
xlabel('Time (min)')
ylabel('Channel Length (m)','FontSize',12)
zlabel('Water Level (m)','FontSize',12)
view(25,20)
m = colorbar
ylabel(m,'Water Level(m)','FontSize',12)
title('Channel Water Level','FontSize',12)
colormap winter
% Reservoir
subplot(4,3,[10:12])
plot(time_plot,h_r,'-.k','LineWidth',2.5)
set(gca,'FontSize',12)
xlabel('Time (min)','FontSize',12); ylabel('Water Level (m)','FontSize',12)
hold on
yyaxis right
set(gca,'ycolor','black')
plot(time_plot,u,'--blue','LineWidth',2.5)
set(gca,'ycolor','black')
ylabel('Control Signal','FontSize',12)
legend('h^{r}','u')
ylim([0 1]);
hold off
export_fig Wshed_Reservoir_Chann_Linearized -m5 -q101 -nocrop
