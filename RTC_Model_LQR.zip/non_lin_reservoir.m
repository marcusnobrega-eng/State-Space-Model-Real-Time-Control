%% Flow Equation
% Developer: Marcus Nobrega
% 4/13/2021
% Goal: Apply manning's overland flow equation considering initial
% abstraction

function [Q,Qcms] = non_lin_reservoir(Lambda,d_0,h_0,Delta_x,Delta_y)
exp_flow = 5/3; % 5/3 for Manning's equation
% d_0 in mm
Qcms = ((Lambda.*(max(0,(d_0/1000 - h_0/1000))).^(exp_flow))); % m3/s'
% idx = isnan(Qcms);
% Qcms(idx) = 0;
Q = (Qcms./(Delta_x*Delta_y))*1000*3600;

% Convert to m3/s to m/s and then to mm/h
end