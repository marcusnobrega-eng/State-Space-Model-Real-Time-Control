%% Watershed + Linearized Reservoir and Channel Dynamics
% 5/7/2021
% Developer: Marcus Nobrega
% Objective: Main file for the MPC controller
clear all
clc
global out_w time_step n_steps Control_Vector Nvars i_reservoir 
%% 1.0 - Topologic Matrices for the Watershed Model
[DEM,n,h_0,ksat,dtheta,I_0,psi,d_0,Delta_x,Delta_y] = gridded_data(); % V-tilted
%[DEM,n,h_0,ksat,dtheta,I_0,psi,d_0,Delta_x,Delta_y] = gridded_parking();
idx = find(DEM == inf);
 % coordinate system from left up corner (x -->) y (down)
[row, col] = find(DEM == min(min(DEM)));
coord_outlet = [row,col];
dim = size(DEM); rows = dim(1); cols = dim(2); % Outlet Position
[f_dir] = FlowDirection(DEM ,Delta_x,Delta_y,coord_outlet); % Flow direction matrix
slope_outlet = 0.02; % m/m
[slope] = max_slope8D(DEM,Delta_x,Delta_y,coord_outlet,f_dir,slope_outlet);
[Direction_Matrix] = Find_D_Matrix(f_dir,coord_outlet);
%% 2.0 - Defining simulation duration
tfinal = 120; % min
time_step = 1; % seconds
time = (0:time_step:tfinal*60)/60; % time vector in min
n_steps = length(time); %number of steps
%% 2.0 - Calculating Flow Constants
% Q = (1/n)*A*Rh^(2/3)*slope^(0.5), A = (Delta_x + Delta_y)/2*d, 
% Rh = A / ((Delta_x + Delta_y)/2 + d) <=> for d << (Delta_x + Delta_y)/2,
% Rh = d -> Q = (1/n)*(Delta_x + Delta_y)/2*d^(2/3)*slope^(0.5)
% Q = (1/n*(Delta_x + Delta_y)/2)*slope(^0.5)*d^(5/3)
% Q = Lambda_1*d^(5/3)
% Lambda_1 = (1/n*(0.5*Delta_x + 0.5*Deltay))*slope^(0.5)
% q = Q / (Delta_x*Delta_y); 
resolution = (Delta_x + Delta_y)/2;
Lambda = (resolution)*(1./n).*slope.^(0.5); % Be careful here
Lambda(idx) = 0;
Lambda = real(Lambda);
Lambda = Lambda(:);
Vcr = (9.81*resolution)^0.5; % critical velocity in m/s
%% 3.0 - Recording Data into a defined step (e.g., each 1-min)
record_time_maps = 1; % time that values will be saved in minutes (e.g., 0.5 it will save each 30 sec)
number_of_records = floor((n_steps-1)*time_step/(record_time_maps*60)); % number of stored data (size of the vector)
time_records = [0:record_time_maps:tfinal]; % time in minutes
% vector to store data
time_store = time_records*60./time_step; % number of steps necessary to reach the recording vector
time_store(1) = 1; % the zero is the firt time step
%% 4.0 - Initial Conditions for the Watershed Model
t = 0;
d = zeros(numel(DEM),length(time_store)); flow_t = d; I = d;
flow_outlet = zeros(length(time_store),1);
d(:,1) = d_0(:);
d_0 = d_0(:);
h_0 = h_0(:);
% Inflows and Inflow_Matrix
[inflows] = non_lin_reservoir(Lambda,d_0,h_0,Delta_x,Delta_y);
Inflow_Matrix = Direction_Matrix;
Inflow_Matrix(Inflow_Matrix == -1) = 0;
%% 5.0 - Rainfall Model 
[i,i_0] = rainfall_model(rows,cols,time_store,number_of_records,record_time_maps); % intensity in mm/h
i_0 = i_0(:);
i = reshape(i,dim(1)*dim(2),length(time_store)); % Results in 2-D array
%% 6.0 - Outlet Position in the concatenated states
% Position in the vector
% Given a 2-D position (eow,col), where row is the row of the outlet and col, the
% collumn of the outlet, we can find pos, such that:
% pos = (y1-1)*rows + x1; 
pos = (col-1)*rows + row;
flow_outlet(1,1) = inflows(pos);
t_store = 1;
% Output function of 1 watershed
out_w = zeros(n_steps,1); % Catchment Outflow (cms)
out_w(1,1) = flow_outlet(1,1);
ETP = 2; % mm/day
ksat = ksat(:);
psi = psi(:);
dtheta = dtheta(:);
I_0 = I_0(:);
%% 7.0 - Solving the Water Balance Equations for the Watersheds
for k = 1:(n_steps - 1)
    % Call the Watershed Matrix Model
    [I_t,d_t,flow_t] = wshed_matrix(d_0,h_0,inflows,time_step,Inflow_Matrix,Direction_Matrix,i_0,ksat,psi,dtheta,I_0,Lambda,Delta_x,Delta_y,ETP);
    % Saving variables with user defined recording time-step
        if k == 1
            % Do nothing, it is already solved, we just have to save the data
            % for the next time-step
        elseif find(time_store == k) > 0
            t_store = find(time_store == k); % Time that is being recorded in min
            d(:,t_store) = d_t(:);
            flow_outlet(t_store,1) = flow_t(pos)*(Delta_x*Delta_y)/(1000*3600); % Flow in cms
            I(:,t_store) = (I_t); % stored depth in mm
        end
    % Saving variables for the next time-step
    I_0 = I_t; % Accumulated Infiltration in (mm)
    z = min(find(time_store >= k)); % Position of raifall
    i_0 = i(:,z); % Initial Rainfall for the next time-step
    d_0 = d_t; % Depths to the next time-step in mm
    inflows = flow_t; % Inflows to the next time-step in mm/h
    % Output Function - Inflow for the Reservoir = Outflow from the
    % Catchment
    out_w(k,1) = flow_t(pos)*(Delta_x*Delta_y)/(1000*3600); % Outflow (cms)
    dmax = d(pos,t_store) % Shows the depth at the outlet
end
%% 8.0 - Setting initial parameters for Reservoir and Channel Dynamics
%%%% Creating concatenated 1D arrays %%%
i_outlet = i(pos,:)';
% Rainfall in the Reservoir
i_reservoir = zeros(n_steps,1);
for k =1:(n_steps-1)
    z = find(time_store <= k, 1,'last' ); % Position of raifall
    i_reservoir(k,1) = i_outlet(z,1); % Initial Rainfall for the next time-step
end
%%
clearvars -except out_w time_step n_steps Control_Vector Nvars i_reservoir
% Channel parameters
[cell_area,y_cells,x_cells,segments,h_radius,h_radius_23,wet_area,outflow,elevation,roughness,slope_out] = channel_parameters(time_step,n_steps);
% Dir Matrices and Slope Matrices
[dir_matrix,A_slope,B_slope] = dir_slope_matrices(segments,y_cells,elevation,slope_out);
% Notation
% (w) - watershed, (r) - Reservoir, (c) channel
% Initial Operation Point for the reservoir
u_eq = 1; % between 0 and 1
h_eq = 0; % (m)
h_rt = 0; % Water level in real time (t = 0) in (m);
% Inflow in the Reservoir
Qin_r = out_w; % Reservoir inflow from the catchment in cms
Qin_rt = out_w(1,1); % Initial reservoir inflow in cms
% Inflow in the Channel
Qin_c = zeros(segments,1);
% Initial Water Depths in the Channel
h_0_c = zeros(segments,1);
% Channel Routing Differential Equation h_dot_channel(:,1) = gama_c(1);
gama_c = 1./cell_area.*(dir_matrix*(1./roughness.*wet_area(h_0_c,x_cells).*h_radius_23(h_0_c,x_cells).*(A_slope*h_0_c + B_slope).^(1/2)) + Qin_c);
% Saving Jacobians alfa_1 alfa_2 beta_1 and beta_2 in a symbolic fashion
[alfa_1_function,alfa_2_function,beta_1_function,beta_2_function] = symbolic_jacobians(); %
%% 9.0 - Running the Model 
x = zeros(n_steps,segments+1);
u = ones(n_steps,1);
out_r_plot = zeros(n_steps,1);
for k = 1:(n_steps - 1)
    % Call Reservoir Routing
    i_0 = i_reservoir(k,1);
    [A_res, B_res,fi_res,out_r,outflow_eq] = state_matrices_reservoir(Qin_rt,h_eq,u_eq,h_rt,time_step,alfa_1_function,alfa_2_function,beta_1_function,beta_2_function,i_0);
    % Call Channel Routing
    [A_chan,fi_c] = state_matrices_channel(time_step,segments,gama_c,dir_matrix,x_cells,A_slope,B_slope,roughness,h_0_c,cell_area,outflow);
    % Concatenate State-Space 
    A = blkdiag(A_res,A_chan);
    n_res = size(A_res,1); % Number of Reservoirs
    n_states = size (A,1); % number of states
    B = [B_res;zeros(n_states - n_res,1)];
    fi = [fi_res;fi_c];
    % x(k+1,:) = A*x(k,:)' + B*u(k,:)' + fi;
    x(k+1,:) = A*x(k,:)' + B*u(k,:)' + fi;
    % Assigning Values for the next-time step for the Reservoir
    Qin_rt = Qin_r(k+1);
    h_eq = x(k+1,1);
    u_eq = u(k+1);
    % Assigning Values for the next time-step for the Channel
    Qin_c(1,1) = out_r;
    gama_c = 1./cell_area.*(dir_matrix*(1./roughness.*wet_area(h_0_c,x_cells).*h_radius_23(h_0_c,x_cells).*(A_slope*h_0_c + B_slope).^(1/2)) + Qin_c);
    h_0_c = x(k+1,2:end)';
    out_r_plot(k) = out_r;
end
% Final Variables
h_r = x(:,1);
h_c = x(:,2:end);
%% Plot Results
graphs_wshed_reservoir_channel_linearized