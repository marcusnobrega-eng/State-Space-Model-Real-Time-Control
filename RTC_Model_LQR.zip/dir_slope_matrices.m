%% Direction Matrix and Slope Matrix Representation
% 5/7/2021
% Developer: Marcus Nobrega
% Goal: Define matrix representations for the topologic relationship
% between each cell of the channel and define a matrix representation to
% refresh the slopes each time-step
function [dir_matrix,A_slope,B_slope] = dir_slope_matrices(segments,y_cells,elevation,slope_out)
%%%%%%%%%%%%%%%%%%%%%%%%% Function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Direction Matrix
dir_matrix = (-1)*eye(segments,segments);
% Slope(k+1) = Aslope*h(k) + Bslope
% Bslope = alfa*theta*elevation
% Aslope = alfa*theta
% alfa = tau*y_cells
% Beta = [0; 0; ... 0; s_outlet];
theta(segments) = 0; % Outlet Cell
theta = eye(segments); % Slope Conection Matrix
tau = 0.5*eye(segments); % Slope Distance Matrix
tau(segments,segments) = 0; % Outlet Cell
beta = zeros(segments,1); 
beta(segments) = slope_out;
for i = 1:(segments - 1)
        dir_matrix(i+1,i) = 1;
        theta(i,i+1) = -1; % [1-1 0 0; 0 1 -1 0 ...]
        tau(i,i+1) = 0.5;
end
alfa = (tau*y_cells).^-1; % 1/Horizontal Distance between cells (m^-1);
alfa(segments) = 0;
alfa = diag(alfa); % Transforming into a diagonal format
B_slope = alfa*theta*elevation' + beta;
A_slope = alfa*theta;