%% Reservoir Area
% 04/25/2021
% Developer: Marcus Nobrega
% Goal - Define the stage-storage function of the reservoir
% You can enter a function using the example below:
% Area = @(h)(coef1*h.^(exp1) + coef2*h.^(exp2) ... );
function [Area_Function,Area,Volume_Function,Volume] = reservoir_area(h,flag_volume)
% We just need to calculate a area function, area, volume_function, and
% volume

% Intitializing Outputs
Area_Function = nan; Area = nan; Volume_Function = nan; Volume = nan;

% Variable Area - Check Example in EWRI Paper
amin = 50; % m2 - initial area for stage = 0
h_1 = 0.9; % Stage 1
h_2 = 1.9; % Stage 2
h_3 = 4.4; % Stage 3
h_4 = 6.9; % Stage 4

% Area Functions
A_1 = @(h) (2833.33333333*h + amin);
A_2 = @(h) (2600 + 59900*(h-0.9));
A_3 = @(h) (62500 + 2080*(h-1.9));
A_4 = @(h) (67700 + 2080*(h-4.4));

% Area and Volume Functions
if h <= h_1
    Area_Function = A_1;
elseif h <= h_2
    Area_Function = A_2;
elseif h <= h_3
    Area_Function = A_3;
else
    Area_Function = A_4;
end
Area = Area_Function(h); % m2 in terms of h in (m)

% Volume - We analytically integrate area function to derive volume
% function
if flag_volume == 1 % It means we are calculating the integrals
    % Volume Calculation (only for 4-stages)
    Vol_delta(1,1) = 0;
    Vol_delta(2,1) = integral(A_1,0,h_1);
    Vol_delta(3,1) = integral(A_2,h_1,h_2) + Vol_delta(2,1);
    Vol_delta(4,1) = integral(A_3,h_2,h_3) + Vol_delta(3,1);
    if h <= h_1
        Volume_Function = @(h) integral(Area_Function,0,h) + Vol_delta(1,1);
    elseif h <= h_2
        Volume_Function = @(h) integral(Area_Function,0.9,h) + Vol_delta(2,1);
    elseif h <= h_3
        Volume_Function = @(h) integral(Area_Function,1.9,h) + Vol_delta(3,1);
    else
        Volume_Function = @(h) integral(Area_Function,4.4,h) + Vol_delta(4,1);
    end
    % Volume for a given stage
    Volume = Volume_Function(h); % m3 in terms of h in (m)
end
end