%% Watershed Model
% Developer: Marcus Nobrega Gomes Junior
% 8/1/2021
% Main Script
% Goal: Create the main file containing:
% a) Watershed Model
% b) Connection between the Optimization Function and the Solvers
% c) Plant Models of the Reservoir and Channel
% d) Saving final results
clear all
clc
%% INPUT DATA %%

input_table = readcell('Input_Main_Data_RTC.xlsx'); % Reading Input data from Excel
input_table(:,1) = [];
input_table(:,2) = [];
for i = 1:numel(input_table)
    if ismissing(input_table{i})
        input_table{i} = 0;
    end
end
input_data = cell2mat(input_table);
flag_reservoir_wshed = input_data(61,1); % If == 1, we subtract the reservoir area * i in the outlet flow

% 1) Running Control
record_time_maps = input_data(2,1);
tfinal = input_data(3,1);
% 2) Watershed Data
slope_outlet = input_data(5,1);
ETP = input_data(6,1);
time_step = input_data(7,1);

% Data
flag_save_data = input_data(47,1);

record_time_hydrographs = input_data(62,1); % Minutes; % We are assuming the same as the rainfall (Minutes)
record_time_ETP = 1440; % Minutes
%% 1.0 - Defining simulation duration
% tifnal is the final minute where the simulation is performed. It has to
% be larger than the rainfall duration in order to make sure the hydrograph
% is propagated properly
time = (0:time_step:tfinal*60)/60; % time vector in min
n_steps = length(time); % number of steps
number_of_records = floor((n_steps-1)*time_step/(record_time_maps*60)); % number of stored data (size of the vector)
number_of_records_hydrographs = floor((n_steps-1)*time_step/(record_time_hydrographs*60)); % number of stored data (size of the vector)
time_records = [0:record_time_maps:tfinal]; % time in minutes
time_records_hydrographs = [0:record_time_hydrographs:tfinal]; % time in minutes
time_records_ETP = [0:record_time_ETP:tfinal]; % time in minutes
% vector to store data
time_store = time_records*60./time_step; % number of steps necessary to reach the recording vector
time_store(1) = 1; % the zero is the firt time step

% Hydrographs and Rainfall
time_store_hydrographs = time_records_hydrographs*60./time_step; % number of steps necessary to reach the recording vector
time_store_hydrographs(1) = 1;

% ETP
time_store_ETP = time_records_ETP*60./time_step; % number of steps necessary to reach the recording vector
time_store_ETP(1) = 1;
%% 2.0 - Watershed Preprocessing
% Call sub - Here we read all watershed information
Watershed_Physics_Input
%% 3.0 - Calculating Flow Constants
resolution = (Delta_x + Delta_y)/2; % Average cell resolution
Lambda = (resolution)*(1./n).*slope.^(0.5); % Lumped hydraulic properties for k = 1
zzz = isinf(DEM) + isnan(DEM); % Logical array with where infs or nans occur
idx = zzz > 0; % Logical array where zzz > 0
Lambda(idx) = 0; % Values with zzz > 0 have no hydraulic properties
Lambda = real(Lambda);
Lambda = Lambda(:); % Concatenated Lambda resultin in a 1-D array
%% 4.0 - Preallocations
d = zeros(numel(DEM),length(time_store)); flow_t = d; I = d; % zeros
flow_outlet = zeros(length(time_store),1);
h_ef_w(:,1) = h_ef_w_0(:);
% Output function of 1 watershed
Qout_w = zeros(length(time_store_hydrographs),1); % Catchment Outflow (cms)
Qout_w(1,1) = flow_outlet(1,1);
% ETP saving
ETP_saving = zeros(length(time_store_hydrographs),1); % Catchment Outflow (cms)
% Position in the vector
% Given a 2-D position (row,col), where row is the row of the outlet and col, the
% collumn of the outlet, we can find pos, such that:
% pos = (y1-1)*rows + x1;
pos = (col-1)*rows + row; % Outlet vector containing the position of the outlet
Depth_out = zeros(length(time_store_hydrographs),1);
Depth_out(1,1) = h_ef_w(pos,1);
f_rate = zeros(1,length(time_store_hydrographs));
f_rate(1,1) = 0;
% Inflow_Matrix
Inflow_Matrix = Direction_Matrix;
Inflow_Matrix(Inflow_Matrix == -1) = 0;
%% 5.0 Evapotranspiration
neg_DEM = DEM < 0;
neg_LULC = LULC < 0;
neg_SOIL = SOIL < 0;
inf_nan_MAPS = isinf(DEM) + isnan(DEM) + neg_DEM + isnan(LULC) + isnan(SOIL) + neg_LULC + neg_SOIL + isinf(LULC) + isinf(SOIL); % Logical array
idx = inf_nan_MAPS > 0;
DEM_1(idx) = 1e-8; % Small value to allow matrix operations
idx_cells = DEM >= 0;
idx_cells = double(idx_cells(:));
% Read ETP data
data_ETP = xlsread('ETP_input.xlsx'); % Read ETP Data
% 1 - date, 2 - Tmed, 3 - Tmax, 4 - Tmin - 5 Vel(2m), 6 - (UR), 7 - G
%%%%% ----- General data of ETP %%%%%% -------
alfa_albedo_input = 0.23; % Assumed value
Krs = 0.16; % Local Coefficient for the determination of Solar Radiation (fixed in 0.16 for continental regions and 0.19 for coastal areas)
lat = -23.62;% centroid latitude of the watershed (decimal degree)
G_input = 0.6; % MJ/(m2.day)

% Converting time
time_ETP = data_ETP(:,1);
time_ETP = datetime(time_ETP, 'ConvertFrom','excel', 'Format','dd-MMM-uuuu');
% Initial Data
Temp = data_ETP(1,2);
Temp_max = data_ETP(1,3);
Temp_min = data_ETP(1,4);
U_2_input = data_ETP(1,5);
U_R_input = data_ETP(1,6);
Day_year = day(time_ETP(1,1),'dayofyear');
% ETP
[ETP] = Evapotranspiration(DEM,Temp,Temp_max,Temp_min,Day_year,lat,U_2_input,U_R_input,Krs,alfa_albedo_input,G_input);
ETP = ETP(:); % So far, ETP is uniform in space and variable in time
ETP_saving(1,1) = ETP(pos);
% ETC = Kc*ETP; Crop Evapotranspiration
%% 6.0 - Groundwater Volume (SWMW like approach)
% Replenishing Coefficient
kr = (1/75*(sqrt(ksat/25.4))); % Replenishing rate (1/hr) (Check Rossman, pg. 110)
Tr = 4.5./sqrt(ksat/25.4); %  Recovery time (hr) Check rossman pg. 110
Lu = 4.*sqrt(ksat/25.4); % Inches - Uppermost layer of the soil
Lu = Lu*2.54/100; % Meters
k_out = (teta_sat - teta_i).*kr.*Lu*1000; % Rate of replenishing exfiltration from the saturated zone during recoverying times (mm/hr)
k_out = k_out(:); % Rate of aquifer replenishing (mm/hr)
%% 7.0 - Rainfall Model
step_rainfall = input_data(12,1); % Minutes
[i,i_0,time_real] = rainfall_model(rows,cols,time_store_hydrographs,number_of_records_hydrographs,record_time_hydrographs,step_rainfall); % Results in 3-D arrays
i = reshape(i,dim(1)*dim(2),length(time_store_hydrographs)); % Results in concatenated 2-D array
%% 8.0 - Array Concatenation
% %%%% Creating concatenated 1D arrays %%%
n = n(:);
h_0 = h_0(:);
ksat = ksat(:);
dtheta = dtheta(:);
F_d = F_0(:);
psi = psi(:);
% Initial Inflow
[inflows] = non_lin_reservoir(Lambda,h_ef_w,h_0,Delta_x,Delta_y);
flow_outlet(1,1) = sum(inflows(pos)*(Delta_x*Delta_y)/(1000*3600)); % Initial Outflow
t_store = 1;

% Making Zeros at Outside Values
i_0 = i_0(:).*idx_cells;
ETP = ETP.*idx_cells;
ksat = ksat(:).*idx_cells;
h_ef_w = h_ef_w.*idx_cells;
psi = psi.*idx_cells;
%ETP = input_data(6,1); % ETP constante no espaço e tempo
% Watershed Area
drainage_area = sum(sum(double(DEM>0)))*resolution^2/1000/1000; % area in km2
%% 9.0 - Solving the Water Balance Equations for the Watersheds
% Read Reservoir Area
hmax = 6.9; % Maximum reservoir area (You've got to enter it). The rationale with this is that rainfall occurs in the top area of the reservoir
[~,Area] = reservoir_area(hmax,0); %
tic % Starts Counting Time
k = 0;
I_previous = F_d;
error = zeros(n_steps,1);
while k <= (n_steps - 1)
    k = k + 1;
    % Rainfall Input
    z = find(time_store_hydrographs <= k, 1,'last' ); % Position of rainfall
    i_0 = i(:,z).*idx_cells; % Initial Rainfall for the next time-step
    if flag_diffusive == 1 % Solving Diffusive-Wave Model
        % Determine the Water Surface Elevation Map
        wse = DEM + 1/1000*reshape(h_ef_w,[],size(DEM,2));
        % Call Flow Direction Sub
        [f_dir,idx_fdir] = FlowDirection(wse,Delta_x,Delta_y,coord_outlet); % Flow direction matrix
        % Call Slope Sub
        [slope] = max_slope8D(wse,Delta_x,Delta_y,coord_outlet,f_dir,slope_outlet); % wse slope
        % Call Dir Matrix
        [Direction_Matrix] = sparse(Find_D_Matrix(f_dir,coord_outlet,Direction_Matrix_Zeros));
        % Calculate Lambda
        Lambda = (resolution)*(1./n).*slope(:).^(0.5); % Lumped hydraulic properties
    end
    % Calculate ETP if the ETP time-step is reached
    % Saving hydrographs and depths with user defined recording time-step
    if k == 1
    elseif find(time_store_ETP == k) > 0 % Typically - Daily
        t_store_ETP = find(time_store_ETP == k); % Time that is being recorded in min
        % Tmed, Tmax, Tmin
        Temp = data_ETP(t_store_ETP,2); % Average
        Temp_max = data_ETP(t_store_ETP,3); % Max
        Temp_min = data_ETP(t_store_ETP,4); % Min
        U_2_input = data_ETP(t_store_ETP,5); % Vel at 2m from surface
        U_R_input = data_ETP(t_store_ETP,6); % Relative humidity in percentage
        Day_year = day(time_ETP(t_store_ETP,1),'dayofyear'); % Convert day in day of the year
        % Call ETP function
        [ETP] = Evapotranspiration(DEM,Temp,Temp_max,Temp_min,Day_year,lat,U_2_input,U_R_input,Krs,alfa_albedo_input,G_input);
        ETP = ETP(:); % Concatenate ETP
    end
    % Call the Watershed Matrix Model
    [F_d,h_ef_w,inflows] = wshed_matrix(h_ef_w,h_0,inflows,time_step,Direction_Matrix,i_0,ksat,psi,dtheta,F_d,Lambda,Delta_x,Delta_y,ETP,idx_fdir,k_out);
    % Saving variables with user defined recording time-step
    if k == 1
        % Do nothing, it is already solved, we just have to save the data
        % for the next time-step
    elseif find(time_store == k) > 0
        t_store = find(time_store == k); % Time that is being recorded in min
        d(:,t_store) = h_ef_w(:); % Depths in mm
        I(:,t_store) = (F_d); % stored depth in mm
        if max(max(d)) > 500
            ttt = 1;
        end
    end

    % Saving hydrographs and depths with user defined recording time-step
    if k == 1
        % Do nothing, it is already solved, we just have to save the data
        % for the next time-step
        t_store_hydrographs= 1;
    elseif find(time_store_hydrographs == k) > 0
        t_store_hydrographs = find(time_store_hydrographs == k); % Time that is being recorded in min
        if flag_reservoir_wshed == 1
            Qout_w(t_store_hydrographs,1) = sum(inflows(pos)*(Delta_x*Delta_y)/(1000*3600)) - Area*i_0(1,1)/1000/3600; % Outflow (cms)
            Depth_out(t_store_hydrographs,1) = 1/1000*h_ef_w(pos); % m
        else
            Qout_w(t_store_hydrographs,1) = sum(inflows(pos)*(Delta_x*Delta_y)/(1000*3600)); % Outflow - Area * i (cms)
            Depth_out(t_store_hydrographs,1) = 1/1000*h_ef_w(pos); % m
            %Qout_w(k,1) = sum(inflows(pos)*(Delta_x*Delta_y)/(1000*3600)); % Outflow - Area * i (cms)
        end
        ETP_saving(t_store_hydrographs,1) = ETP(pos); % ETP value in mm/day but at rain and flow time-step
        % Average Infiltration
        I_actual = F_d; % mm in each cell
        Vol_begin = sum(I_previous.*idx_cells)/(1000*1000*drainage_area/(resolution^2)); % mm per cell in average
        Vol_end = sum(I_actual.*idx_cells)/(1000*1000*drainage_area/(resolution^2)); % mm per cell in average
        f_rate(1,t_store_hydrographs) = (Vol_end - Vol_begin)/(record_time_hydrographs/60); % mm/hr; % Soil flux
        I_previous = I_actual;
    end

    perc = k/(n_steps-1)*100;
    perc_______qoutw______depthw___infexut___timeremain____ETP = [perc,Qout_w(t_store_hydrographs,1),Depth_out(t_store_hydrographs,1),I(pos,t_store),toc*100/perc/3600,ETP(pos)] % Showing the depths at the outlet and the percentage of the calculations a

    % Check if a Steady Dry Condition is Reached
    if max(h_ef_w) == 0 && max(F_d) == 5
        z = find(time_store_hydrographs <= k, 1,'last' ); % Position of rainfall
        zz = find(i(pos,z:end) > 0,1,'first') + z - 1;
        k = zz*step_rainfall*60/time_step - 2;
        t_new = find(time_store_ETP <=k,1,'last'); % Time that is being recorded in min
        % Tmed, Tmax, Tmin
        Temp = data_ETP(t_new,2); % Average
        Temp_max = data_ETP(t_new,3); % Max
        Temp_min = data_ETP(t_new,4); % Min
        U_2_input = data_ETP(t_new,5); % Vel at 2m from surface
        U_R_input = data_ETP(t_new,6); % Relative humidity in percentage
        Day_year = day(time_ETP(t_new,1),'dayofyear');
        % Call ETP function
        [ETP] = Evapotranspiration(DEM_1,Temp,Temp_max,Temp_min,Day_year,lat,U_2_input,U_R_input,Krs,alfa_albedo_input,G_input);
        ETP = ETP(:);
        I_previous = F_d;
        ETP_saving(t_new+1,1) = ETP(pos); % ETP value in mm/day
    end

    %%% ------------- Mass Balance Routine  ------------------- %%%
    rain = i_0(pos); % mm/h
    etp_rate = ETP(pos)/24 ; % mm/h
    exf = sum(sum(k_out))/(sum(sum(double(idx_cells)))); % average k_out for all catchment (mm/h)
    Q = sum(inflows(pos)*(Delta_x*Delta_y)/(1000*3600)); % m3/s of outflow
    S_t_1 = drainage_area*1/1000*sum(F_d.*idx_cells)/(1000*1000*drainage_area/(resolution^2)); % m3
    S_t = S_t_1;
    % Mathematical Background for Error Evaluation
    % i*dt = Q*dt + ETP*dt - Exf*dt - DS (Mass Balance Equation)
    % DS = [(Q + (ETP - Exf - i)A]dt (Storage Variation = S(t+1) - S(t))
    % S(t+1) - S(t) = [Q + (ETP - Exf - i)A]dt
    % Mass Balance Error
    % e1 = S(t+1) - S(t) (error 1)
    % e2 = (Q + ETP - Exf - i)dt (error 2)
    % error = e1 - e2 ; this has to be 0
    e1 = S_t_1 - S_t;
    e2 = time_step*(Q + 1/1000/3600*(etp_rate - exf - rain)*drainage_area); % m3
    error(k) = e1 - e2;
end
watershed_runningtime = toc/60; % Minutes

%% 10.0 - Watershed Post-Processing
% Call sub - Generate GIFs, Hydrographs, and so on
watershed_post_processing
% We recommend saving the workspace such as
save('workspace_waterhsed');
