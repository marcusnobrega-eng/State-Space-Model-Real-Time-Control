%% Reservoir Area
% 04/25/2021
% Developer: Marcus Nobrega
% Goal - Define the stage-storage function of the reservoir
% You can enter a function using the example below:
% Area = @(h)(coef1*h.^(exp1) + coef2*h.^(exp2) ... );
function [Area_Function,Area] = reservoir_area(h)
Catchment_Area = 1.62*1000*1000; % m2
ratio = 0.65/100;
Area_calculated = ratio*Catchment_Area;
Area_Function = @(h) (Area_calculated); % previously 8100
Area = Area_Function(h); % m2
end