%% Channel Routing Parameters
% Developer - Marcus Nobrega
% 5/7/2021
% Objective: Initialized parameters for the channel routgin
function [cell_area,y_cells,x_cells,segments,h_radius,h_radius_23,wet_area,outflow,elevation,roughness,slope_out] = channel_parameters(time_step,n_steps)
%%%%%%%%%%%%%%%%%%%%%%%%%% Parameters only %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Time-step
delta_t = time_step; % Seconds;
x_length = 3;
y_length = 30;
% Manning's
roughness = 0.30;
% Noise in Manning
average = 0;
variance = 0.00;  % r = (1 + average + sqrt(variance).*randn())
% Number of Segments
segments = 100;
x_cells = repmat(x_length,[segments,1]);
y_cells = repmat(y_length,[segments,1]);
roughness = repmat(roughness,[segments,1]);
% Elevation Calculation
s = 0.025; % slope m/m
slope_out = 0.025; % Outlet slope m/m
h_end = 0; % m
% Bottom Elevation
for i = 1:segments
    if i == 1
        elevation(1) = sum(y_cells*s)+ h_end;
        r = (1 + average + sqrt(variance).*randn()); % Noise
        roughness(i) = roughness(i)*r;
    else
        elevation(i) = elevation(i-1) - s*y_cells(i-1);
        r = (1 + average + sqrt(variance).*randn()); % Noise
        roughness(i) = roughness(i)*r;
    end
end
% Cells Area
cell_area = x_cells.*y_cells; % m2
%% 2.0 - Hydraulic Radius and Area Function
h_radius = @(h,b) ((b.*h)./(b + 2.*h)); % User defined hydraulic radius function
h_radius_23 = @(h,b) (((b.*h)./(b + 2*h)).^(2/3)); % Rh^(2/3), handle
wet_area = @(h,b) (b.*h); % User defined cross section area function
outflow = @(h,b,roughness,slope) (1./roughness.*wet_area(h,b).*(h_radius(h,b).^(2/3)).*(slope.^(0.5))); % Manning's
end
