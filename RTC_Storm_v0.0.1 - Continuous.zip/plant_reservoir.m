%% Reservoir Dynamics - Main Script
% 4/25/2021
% Note - I added rainfall in the area of the reservoir
% Developer: Marcus Nobrega
% Goal - Develop a linearized state-space represenntation of the Reservoir
% Dynamics
% Last Edited: 11/14/2021
function [h_r,Qout_r] = plant_reservoir(Qout_w,time_step,u,g,Cd,number_of_orifices,flag_c,D,flag_r,l,b,hmin,orifice_height,Cds,Lef,hs,porosity,average,variance)
global Qout_w Qout_w_horizon steps_control_horizon steps_horizon time_step n_steps Control_Vector Nvars i_reservoir h_c_0 h_r_t ur_eq_t i_reservoir_horizon previous_control average variance slope_outlet tfinal record_time_maps ETP new_timestep Control_Interval Control_Horizon Prediction_Horizon g Cd flag_r number_of_orifices D l b relative_hmin Cds Lef hs porosity orifice_height x_length y_length roughness segments slope slope_outlet_channel max_iterations max_fun_eval n_randoms flag_c flag_r hmin s h_end slope_outlet_channel n_channel
%% Reservoir Parameters
h_eq = h_r_t; % m
% h_r_t = 0; % Initial Water Level in the Reservoir (m)
ur_eq = ur_eq_t; % boolean (0-1), 1 is fully opened, 0 is fully closed
T = time_step; % seconds
[Area_Function] = reservoir_area(0) ; % A = f(h) (handle) Function of h (to change, is required to change the function)
Aoc = pi()*D^2/4*number_of_orifices;
Aor = l*b*number_of_orifices;
if ((flag_c == 1) && (flag_r == 1)) 
    error('Please choose only one type of orifice')
elseif (flag_c == 1)    
    D_h = D; % circular
    Ao = Aoc;
else
    D_h = 4*(l*b)/(2*(l+b)); % rectangular
    Ao = Aor;
end
h_flow = max(hmin*D_h,orifice_height);
% Inflow
Qin = Qout_w_horizon; % m3/s
% Flow Equation
outflow_eq = @(Ko,Ks,h,hs,ho,ur_eq) (Ko.*ur_eq.*sqrt(max(h - h_flow,0)) + max(Ks.*(h - hs),0).^(3/2)); % Reservoir Outflow Function
%% Calculating Constants
Ko = Cd*Ao*sqrt(2*g); Ks = Cds*Lef; % Reservoir Constants
%% Symbolic Alfa and Beta Matrices
[alfa_1_function,alfa_2_function,beta_1_function,beta_2_function] = symbolic_jacobians(); %  maybe we dont need
%% Determining Jacobian Matrices
Qin_t = Qin(1);
i_0 = i_reservoir_horizon(1,1); %%%% fix it here
[alfa_tilde,beta_tilde] = alfabeta_matrices(Qin_t,Ko,ur_eq,h_eq,h_flow,Ks,hs,h_r_t,alfa_1_function,alfa_2_function,beta_1_function,beta_2_function,D_h);% Calculating alfa and beta
gama_tilde = (1/(Area_Function(h_eq)*porosity)*(Qin_t - outflow_eq(Ko,Ks,h_eq,hs,h_flow,ur_eq))) + i_0/1000/3600; % Adding Net Rainfall
gama_tilde(isnan(gama_tilde))=0;
%% Discretizing the System
A = (1 + T*alfa_tilde);
B = (T*beta_tilde);
fi = (T*gama_tilde - T*alfa_tilde*h_eq - T*beta_tilde*ur_eq);
% h(k+1) = A*h(k) + B*u + fi(k)
h = zeros(steps_horizon,1) ; h(1,1) = h_r_t;
%% Main for Loop
for k = 1:(steps_horizon-1)    
    k/steps_horizon*100;
    [g_noise] = gaussian_noise_generator(variance,average);
    h(k+1) = max(A*h(k) + B*u(k,1) + fi + g_noise ,0); % Constraint to make water level positive
    Qin_t = Qin(k+1);
    i_0 = i_reservoir_horizon(k,1); % Initial Rainfall for the next time-step
    h_t = h(k);
    % New Operation Point
    h_eq = h(k);
    ur_eq = u(k);
    % Jacobians
    [alfa_tilde,beta_tilde] = alfabeta_matrices(Qin_t,Ko,ur_eq,h_eq,h_flow,Ks,hs,h_t,alfa_1_function,alfa_2_function,beta_1_function,beta_2_function,D_h);   
    % Calculating gama_tilde
    gama_tilde = (1/(Area_Function(h_eq)*porosity)*(Qin_t - outflow_eq(Ko,Ks,h_eq,hs,h_flow,ur_eq))) + i_0/1000/3600;
    gama_tilde(isnan(gama_tilde))=0;
    % New State-Space
    A = (1 + T*alfa_tilde);
    B = (T*beta_tilde);
    fi = (T*gama_tilde - T*alfa_tilde*h_eq - T*beta_tilde*ur_eq);
end
Qout_r = outflow_eq(Ko,Ks,h,hs,h_flow,u);
h_r = h;