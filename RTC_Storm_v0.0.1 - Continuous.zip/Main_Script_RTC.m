%% Main File - MPC solver for the Watershed + Reservoir + Channel system
% Developer: Marcus Nobrega Gomes Junior
% 8/1/2021
% Main Script 
% Goal: Create the main file containing:
% a) Watershed Model
% b) Connection between the Optimization Function and the Solvers
% c) Plant Models of the Reservoir and Channel
% d) Saving final results
clear all
clc
global Qout_w Qout_w_horizon steps_control_horizon steps_horizon time_step n_steps Control_Vector Nvars i_reservoir h_c_0 h_r_t ur_eq_t i_reservoir_horizon previous_control average variance slope_outlet tfinal record_time_maps ETP new_timestep Control_Interval Control_Horizon Prediction_Horizon g Cd flag_r number_of_orifices D l b relative_hmin Cds Lef hs porosity orifice_height x_length y_length roughness segments slope slope_outlet_channel max_iterations max_fun_eval n_randoms flag_c flag_r hmin s h_end slope_outlet_channel n_channel a_noise b_noise
%% INPUT DATA %%

% 1) Running Control
record_time_maps = 15;% % time that values will be saved in minutes (e.g., 0.5 it will save each 30 sec)
tfinal = 132475 + 24*60; % min
% 2) Watershed Data
slope_outlet = 0.02;% outlet slope in m/m
ETP = 2;% mm/day
time_step = 5; % Time-step of the watershed hydrological model in (seconds)
% 3) Reservoir Data
g = 9.81;% m/s
Cd = 0.61;% 
flag_r = 0;% 1 if the orifice is rectangular, 0 if it is circular
flag_c = 1;% 1 if the orifice is circular
number_of_orifices = 2;% 
D = 0.6;% m
l = 1;% m
b = 1.2;% m
relative_hmin = 0.2;% hmin = relative_hmin*D_h, minimum water level to start flows
Cds = 2.1;% spillway discharge coefficient
Lef = 3;% Effective spilway length (m)
hs = 5.5;% Spillway height in (m)
porosity = 1;% Reservoir porosity
orifice_height = 0;% orifice height from the bottom of the reservoir in (m)
ur_eq_t = 1;
h_r_t = 0;
hmin = 0.2; % minimum orifice percentage

% 4) Channel Data
x_length = 3;% m
y_length = 30;% m
n_channel = 0.3;% 
segments = 100;% 
h_end = 0; % Elevation of the last cell of the channel in m
s = 0.025; % bed slope m/m
slope_outlet_channel = 0.025; % Outlet slope m/m
h_c_0 = zeros(segments,1);

% 5) MPC Control
new_timestep = 1;% seconds
Control_Interval = 1*60; % actions are taken in this interval (min)
Control_Horizon = 2*60; % we plan and implement control in this horizon and move foward (min)
Prediction_Horizon = 2*60; % (min) we solve the optimization problem for this duration, implement actions for 1 control horizon and move 1 control horizon
% 5.1) Interior Point Solver
max_iterations = 10; % Maximum number of iterations
max_fun_eval = 50; % Maximum function evaluations
%%%% Range of the Initial Values %%%%
a_noise = -0.2; % initial values varies within this range from the previous last value
b_noise = 0.2;
% 5.1.1) Randoms
n_randoms = 2;
% Initial Equilibrium Points for the Reservoir
ur_eq = 0; % Initial equilibrium point, between 0 and 1
hr_eq = 0.1; % Initial equilibrium point (water level in the pond) in (m)
% Data
flag_save_data = 1; % if 1, saves .txt files from output results
%% 1.0 - Defining simulation duration
% tifnal is the final minute where the simulation is performed. It has to
% be larger than the rainfall duration in order to make sure the hydrograph
% is propagated properly
time = (0:time_step:tfinal*60)/60; % time vector in min
n_steps = length(time); % number of steps
number_of_records = floor((n_steps-1)*time_step/(record_time_maps*60)); % number of stored data (size of the vector)
time_records = [0:record_time_maps:tfinal]; % time in minutes
% vector to store data
time_store = time_records*60./time_step; % number of steps necessary to reach the recording vector
time_store(1) = 1; % the zero is the firt time step
%% 2.0 - Watershed Preprocessing
% Call sub
Watershed_Preprocessing
%% 3.0 - Calculating Flow Constants
resolution = (Delta_x + Delta_y)/2;
Lambda = (resolution)*(1./n).*slope.^(0.5); % Lumped hydraulic properties
Lambda(idx) = 0; % inf cells
Lambda = real(Lambda);
Lambda = Lambda(:); % Concatenated Lambda resultin in a 1-D array
%% 4.0 - Preallocations
d = zeros(numel(DEM),length(time_store)); flow_t = d; I = d; % zeros
flow_outlet = zeros(length(time_store),1);
h_ef_w(:,1) = h_ef_w_0(:);
% Output function of 1 watershed
Qout_w = zeros(n_steps,1); % Catchment Outflow (cms)
Qout_w(1,1) = flow_outlet(1,1);
% Inflow_Matrix
Inflow_Matrix = Direction_Matrix;
Inflow_Matrix(Inflow_Matrix == -1) = 0;
%% 5.0 - Rainfall Model 
[i,i_0] = rainfall_model(rows,cols,time_store,number_of_records,record_time_maps); % Results in 3-D arrays
i = reshape(i,dim(1)*dim(2),length(time_store)); % Results in 2-D array
i_0 = i_0(:);
%% 6.0 - Outlet Position and Array Concatenation
% Position in the vector
% Given a 2-D position (row,col), where row is the row of the outlet and col, the
% collumn of the outlet, we can find pos, such that:
% pos = (y1-1)*rows + x1; 
pos = (col-1)*rows + row; % Outlet vector containing the position of the outlet
%%%% Creating concatenated 1D arrays %%%
n = n(:);
h_0 = h_0(:); 
ksat = ksat(:);
dtheta = dtheta(:);
F_d = F_0(:);
psi = psi(:);
h_ef_w = h_ef_w_0(:);
% Initial Inflow
[inflows] = non_lin_reservoir(Lambda,h_ef_w,h_0,Delta_x,Delta_y);
flow_outlet(1,1) = sum(inflows(pos)*(Delta_x*Delta_y)/(1000*3600)); % Initial Outflow
t_store = 1;
ETP = 2;
%% 7.0 - Solving the Water Balance Equations for the Watersheds
for k = 1:(n_steps - 1)    
    % Call the Watershed Matrix Model
    [F_d,h_ef_w,inflows] = wshed_matrix(h_ef_w,h_0,inflows,time_step,Inflow_Matrix,Direction_Matrix,i_0,ksat,psi,dtheta,F_d,Lambda,Delta_x,Delta_y,ETP);
    % Saving variables with user defined recording time-step
        if k == 1
            % Do nothing, it is already solved, we just have to save the data
            % for the next time-step
        elseif find(time_store == k) > 0
            t_store = find(time_store == k); % Time that is being recorded in min
            d(:,t_store) = h_ef_w(:); % Depths in mm
            flow_outlet(t_store,1) = sum(inflows(pos)*(Delta_x*Delta_y)/(1000*3600)); % Flow in cms
            I(:,t_store) = (F_d); % stored depth in mm
        end
    % Saving variables for the next time-step
    z = find(time_store <= k, 1,'last' ); % Position of raifall
    i_0 = i(:,z); % Initial Rainfall for the next time-step
    % Output Function - Inflow for the Reservoir = Outflow from the
    % Catchment
    Qout_w(k,1) = sum(inflows(pos)*(Delta_x*Delta_y)/(1000*3600)); % Outflow (cms)
    perc = k/(n_steps-1)*100;
    info = [perc] % Showing the depths at the outlet and the percentage of the calculations a
end
%% 8.0 Modeling Reservoir + Channel Dynamics
% Pre allocating arrays
h_r = zeros(n_steps,1); % Depth in the reservoir (m)
i_reservoir = zeros(n_steps,1);
u_begin = ur_eq_t; % Initial control law
i_outlet = i(pos,:)'; % Rainfall in the outlet
% Evaporation in the Reservoir (timeseries or constant value)
% E = 4.1092; % mm/day - Average ETP in San Antonio
E = 2; % mm/day
% Net Rainfall For-Loop
for k =1:(n_steps-1)
    z = find(time_store <= k,1,'last'); % Be careful here
    i_reservoir(k,1) = i_outlet(z,1); % Initial Net Rainfall for the next time-step
end
%% 9.0 Agregating time-step to increase speed
% Agregating the Inflow to a larger time-step
% You can either enter with your observed outflow from the watershed and
% observed rainfall or use the ones calculated previously.
% To gain velocity, we can enter these values loading these files below:
    %%%% Example %%%%
    % load out_w_10_yr ;(outflow from watershed)
    % load i_reservoir_data  ;(rainfall in mm/h)
% Loading Files
load out_w_2months
Qout_w = out_w;
load i_reservoir_2months
% load Watershed_Outflow_Data_25yr_10yr
% load i_reservoir_25yr_10yr
E = 2; % mm/day
%%%% Net Rainfall i'(k)
i_reservoir = i_reservoir - E/24; % Rainfall intensity - Evaporation Intensity (mm/h)
% All this previously done is to to avoid to run the watershed model, but
% you can run of course
%%%% Agregating Time-Steps %%%%
flow_timestep = time_step;
inflow_timesteps = n_steps; % Number of time-steps using the watershed time-step
n_steps = (n_steps-1)*time_step/new_timestep; % adjusting the new number of time-steps
Qout_w_disagregated = Qout_w;
agregation_step = new_timestep/time_step; % number of time-steps in on agregation time-step
% Preallocating Arrays
n_steps_disagregation = (inflow_timesteps/agregation_step-1);
flow_agregated = zeros(n_steps_disagregation,1);
i_reservoir_agregated = zeros(n_steps_disagregation,1);
% Disagregating or Agreagating flows and rainfall
for i = 1:n_steps_disagregation
    if new_timestep >= time_step
        flow_agregated(i,1) =  mean(Qout_w_disagregated(1 + (i-1)*agregation_step:i*agregation_step,1));
        i_reservoir_agregated(i,1) = mean(i_reservoir(1 + (i-1)*agregation_step:i*agregation_step,1));
    else
        flow_agregated(i,1) =  Qout_w_disagregated(1 + floor((i-1)*agregation_step):ceil(i*agregation_step));
        i_reservoir_agregated(i,1) = i_reservoir(1 + floor((i-1)*agregation_step):ceil(i*agregation_step));
    end
end
% Defining updated outflows from the watershed, rainfall intensity and
% time_step
Qout_w = flow_agregated;
i_reservoir = i_reservoir_agregated;
time_step = new_timestep;
%% 10.0 Calling MPC control
% Let's clear variables we don't use to avoid computational burden
clearvars -except Qout_w Qout_w_horizon steps_control_horizon steps_horizon time_step n_steps Control_Vector Nvars i_reservoir h_c_0 h_r_t ur_eq_t i_reservoir_horizon previous_control average variance slope_outlet tfinal record_time_maps ETP new_timestep Control_Interval Control_Horizon Prediction_Horizon g Cd flag_r number_of_orifices D l b relative_hmin Cds Lef hs porosity orifice_height x_length y_length roughness segments slope slope_outlet_channel max_iterations max_fun_eval n_randoms flag_c flag_r hmin s h_end slope_outlet_channel n_channel a_noise b_noise
tic

% a) A few vector calculations
steps_control_horizon = Control_Horizon*60/time_step; % number of steps in the control horizon;
n_controls = Control_Horizon/Control_Interval; % number of controls to choose from an optimization problem
steps_horizon = Prediction_Horizon*60/time_step; % number of steps in one prediction horizon
Qout_w(length(Qout_w):(length(Qout_w)+steps_horizon),1) = 0; % adding more variables to the inflow to account for the last prediction horizon
i_reservoir(length(i_reservoir):(length(i_reservoir)+steps_horizon),1) = 0; % adding more variables to the inflow to account for the last prediction horizon
n_horizons = (n_steps)/(Control_Horizon*60/time_step); % number of control horizons 
Control_Vector = [0:Control_Interval:Prediction_Horizon]*60/time_step;
Nvars = length(Control_Vector);

% b) Objective Function
fun = @Optimization_Function;

% c) Optmizer - Solver
%%%% Interior Point %%%
options = optimoptions(@fmincon,'MaxIterations',max_iterations,'MaxFunctionEvaluations',max_fun_eval); % Previously
%%%% To increase the chances of finding global solutions, we solve the problem
% for n_randoms initial points %%%%

%%%% Estimate random initial points for the Random Search %%%%
matrix = rand(Nvars,n_randoms);
% u(k+1) = u(k)*rand(0,0.2)
% Matrices for FMINCON
A = []; B = []; Aeq = [];Beq = []; Lb = zeros(Nvars,1); Ub = ones(Nvars,1);
%%% Prealocatting Arrays %%%
h_r_final = zeros(n_steps,1);
h_c_final = zeros(segments,n_steps);
U = zeros(Nvars,1); % Concatenation of future control signals
previous_control = 0;
u = 0; % initial control
for i = 1:n_horizons
    perc = i/n_horizons*100
    % Define inflow from the catchment during the prediction horizon
    time_begin = (i-1)*steps_control_horizon + 1; % step
    t_min = time_begin*time_step/60; %  time in min
    time_end = time_begin + steps_horizon; 
    t_end = time_end*time_step/60; % final time of the current step
    time_end_saving = time_begin + steps_control_horizon-1; % for saving    
    Qout_w_horizon = Qout_w(time_begin:time_end,1); % Result of the Watershed Model
    i_reservoir_horizon = i_reservoir(time_begin:time_end,1); % Result of the Rainfall Forecasting
    % Determining random initial points    
    %%% Noise Generation - Prediction %%%
    % In case noise is generated in the states, you can model it by a
    % assuming a Gaussian noise with an average and variance specified
    % below
    average = 0.0; % average noise in (m)
    variance = 0; % variance in (m2). Remember that xbar - 2std has a prob of 93... %, std = sqrt(variance)
    
    % Generating initial estimates for the search algorithm
    for j=1:n_randoms
        if u(end,1) == 0 % In case the previous control equals zero
            u0 = matrix(:,j); % Random numbers
            u0(1) = U(n_controls);
        else
            u0 = U(n_controls)*(a_noise + matrix(:,j)*(b_noise - a_noise)); % randomly select values within the adopted range
            u0(1) = U(n_controls); % the initial estimative is the previous adopted
        end
        if max(Qout_w_horizon) == 0 % If the maximum predicted outflow is zero
            U = ur_eq_t*(ones(Nvars,1)); % Here you can either choose to open the valves or close them, in case you want to increase detention time
        else
            %%% Solving the Optimization Problem for the Random Initial
            %%% Points
            [U,FVAL] = fmincon(fun,u0',A,B,Aeq,Beq,Lb,Ub,[],options);  % Fmincon solutions          
            OF(j) = FVAL; % saving the objective function value
            U_random(:,j) = U'; % saving the control vector     
            position = find(OF == min(OF)); % position where the minimum value of OF occurs
            U = U_random(:,position); % Chosen control            
        end
    end
    controls((i-1)*n_controls + 1:i*n_controls,1) = U(1:n_controls)';
    % Implement the Controls in the Plant and retrieving outputs
    %%% Run the Model with the estimated trajectory determined previously %%%
    % Disagregating u into the time-steps of the model
    for j=1:(steps_horizon)
        idx = find(Control_Vector < j,1,'last'); % U disagregated into time-steps
        u(j,1) = U(idx);
    end
    previous_control = U(n_controls);    
    %%% Noise Generation - Application %%%
    % In case noise is generated in the states, you can model it by a
    % assuming a Gaussian noise with an average and variance specified
    % below (This applies only to the plant)
    average = 0.0; % average noise in (m)
    variance = 0; % variance in (m2). Remember that xbar - 2std has a prob of 93... %, std = sqrt(variance)
    
    %%% Reservoir Plant %%%
    [h_r,out_r] = plant_reservoir(Qout_w,time_step,u,g,Cd,number_of_orifices,flag_c,D,flag_r,l,b,hmin,orifice_height,Cds,Lef,hs,porosity,average,variance); % Reservoir Dynamics
    h_r_t = h_r(steps_control_horizon); ur_eq_t = U(n_controls); % Initial values for the next step
    %%% Channel Plant %%%
    [max_water_level,h_c,out_c] = plant_channel(out_r,time_step,h_c_0,x_length,y_length,roughness,average,variance,segments,s,slope_outlet_channel,h_end); % Channel Dynamics
    h_c_0 = h_c(:,steps_control_horizon); % Initial Values for the next step
    %%% Saving Results %%%
    h_r_final(time_begin:time_end_saving,1) = h_r(1:steps_control_horizon,1);
    out_r_final(time_begin:time_end_saving,1) = out_r(1:steps_control_horizon,1);
    h_c_final(:,(time_begin:time_end_saving)) = h_c(:,1:steps_control_horizon);
    out_c_final(time_begin:time_end_saving,1) = out_c(1:steps_control_horizon,1);
end
%% 11.0 Disagregating controls to the time-step unit
Control_Vector = [0:Control_Interval*60/time_step:n_steps];
for i=1:(n_steps-1)
    idx = find(Control_Vector <= i,1,'last'); % Position in U
    u(i,1) = controls(idx);
end
u = [u_begin; u];
%graphs_wshed_reservoir_channel
display_results;


