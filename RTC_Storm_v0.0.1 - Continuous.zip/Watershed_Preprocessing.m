%% Watershed Input Data and Pre-processing
% Developer: Marcus Nobrega Gomes Junior
% 11/3/2021
% Goal: Input Watershed Data and Perform Initial Processing
%% 1.0 - Gridded Information of Watershed Properties
% We need matrices representing the DEM, roughness, initial abstraction,
% saturated hydraulic conductivity, inintial infiltrated depth, suction
% head, as well as cell resolutions for x and y directions.

% The following function estimates it for the V-Tilted Catchment. However,
% you might change it loading these aforementioned files below following these names:
% Digital Elevation Model --------------------------- DEM (m)
% Manning's roughness coefficient ------------------- n (S.I units)
% Saturated Hydraulic Conductivity ------------------ ksat (mm/hr)
% Soil moisture deficit (\theta_{sat} - \theta_i) --- dtheta 
% Initial soil moisture content --------------------- F_0 (mm)
% Cell resolution in x direction -------------------- Delta_x (m)
% Cell resolution in y direction --------------------- Delta_y (m)

%%%%%%%%%%%%%%%%%%%%%%% V-Tilded Data %%%%%%%%%%%%%%%%%%%%%%%
[DEM,n,h_0,ksat,dtheta,F_0,psi,h_ef_w_0,Delta_x,Delta_y] = gridded_data(); % V-tilted (7/24/2021 - Overland Flow)
%%%%%%%%%%%%%%%%%%%%%%% V-Tilded Data %%%%%%%%%%%%%%%%%%%%%%%

% See an example of how you could do in case you want to log a different
% watershed
% In case manual text files are inputed, please make sure to load them
% folowing this:
%   load DEM
%   load n
%   load h_0
%   load ksat
%   load dtheta
%   load F_0
%   load psi
%   load h_ef_w_0
%   Delta_x = %%% length of the cells in meters
%   Delta_y = %%% width of the cells in meters

%%% 1.1 - Filling Sinks %%%
% We are using a kinematic wave approximation for the Saint Vennant
% Equations. Therefore, we need to assign a flow direction for each cell.
% In other words, cells with sinks have to be filled. The following
% calculations fill sinks in the DEM.
idx = find(DEM == inf);

%%% 1.2 - Flow Direction, Slope and Direction Matrix %%%
 % coordinate system from left up corner (x -->) y (up-down)
[row, col] = find(DEM == min(min(DEM)));
coord_outlet = [row,col];
dim = size(DEM); rows = dim(1); cols = dim(2);

%%%% Flow Direction %%%%
[f_dir] = FlowDirection(DEM ,Delta_x,Delta_y,coord_outlet); % Flow direction matrix

%%%% Slope Calculation %%%%
[slope] = max_slope8D(DEM,Delta_x,Delta_y,coord_outlet,f_dir,slope_outlet);

%%%% Direction Matrix %%%%
[Direction_Matrix] = Find_D_Matrix(f_dir,coord_outlet);