%% Watershed Physic Infomration
% Marcus Nóbrega & Matheus Schroeder 
% 09/2022

%% Data in txt format (Gis Data)
% Here you should upload your LULC, DEM, and SOIL maps
% 
LULC = load('LULC_50v04_int.asc'); % Land Use and Land Cover Classification
DEM = load('MDE_50_v04.asc'); % Digital Elevation Model
SOIL = load('SOIL_50v04.asc'); % Soil Map

Impervious_LULC = 0; % Assigned value for impervious areas
idx_impervious = LULC == Impervious_LULC; % Logical Array
%% Treating Values with Issues
neg_DEM = DEM <= 0;
neg_LULC = LULC < 0;
neg_SOIL = SOIL < 0; 
inf_nan_MAPS = isinf(DEM) + isnan(DEM) + neg_DEM + isnan(LULC) + isnan(SOIL) + neg_LULC + neg_SOIL + isinf(LULC) + isinf(SOIL); % Logical array
idx = inf_nan_MAPS > 0;

%Replacing Values with Issues 
DEM(idx) = nan;
% LULC(idx) = 1e-6;
% SOIL(idx) = nan;

 %% Set up the Import Options and import the data
Input_LULC = readtable('Input_LULC_Data_RTC.csv');
InputLULCDataRTC = table2array(Input_LULC);

Input_Soil = readtable('Input_Soil_Data_RTC.csv');
InputSoilDataRTC = table2array(Input_Soil);

%% LULC Parameters
LULC_roughness = InputLULCDataRTC(:,1);
LULC_h_0 = InputLULCDataRTC(:,2);

%% Soil Parameters
Soil_map_sat = InputSoilDataRTC(:,1);
Soil_map_i = InputSoilDataRTC(:,2);
Soil_map_psi = InputSoilDataRTC(:,3);
Soil_map_ksat = InputSoilDataRTC(:,4);
Soil_map_F_0 = InputSoilDataRTC(:,5);
Soil_map_h_ef_w_0 = InputSoilDataRTC(:,6);

%% Assigning Values for Each Soil and LULC value
%% Theta Sat
teta_sat = SOIL;

teta_sat(teta_sat(:,:)==1) = Soil_map_sat(1,1);
teta_sat(teta_sat(:,:)==2) = Soil_map_sat(2,1);
teta_sat(teta_sat(:,:)==3) = Soil_map_sat(3,1);
teta_sat(teta_sat(:,:)==4) = Soil_map_sat(4,1);
teta_sat(teta_sat(:,:)==5) = Soil_map_sat(5,1);
teta_sat(teta_sat(:,:)==6) = Soil_map_sat(6,1);
teta_sat(teta_sat(:,:)==7) = Soil_map_sat(7,1);
% teta_sat(teta_sat(:,:)<0) = nan;

%% teta_i
teta_i = SOIL;

teta_i(teta_i(:,:)==1) = Soil_map_i(1,1);
teta_i(teta_i(:,:)==2) = Soil_map_i(2,1);
teta_i(teta_i(:,:)==3) = Soil_map_i(3,1);
teta_i(teta_i(:,:)==4) = Soil_map_i(4,1);
teta_i(teta_i(:,:)==5) = Soil_map_i(5,1);
teta_i(teta_i(:,:)==6) = Soil_map_i(6,1);
teta_i(teta_i(:,:)==7) = Soil_map_i(7,1);
% teta_i(teta_i(:,:)<0) = nan;
teta_i(teta_i(:,:)<0) = 0;

%% F_0
F_0 = SOIL;

F_0(F_0(:,:)==1) = Soil_map_F_0(1,1);
F_0(F_0(:,:)==2) = Soil_map_F_0(2,1);
F_0(F_0(:,:)==3) = Soil_map_F_0(3,1);
F_0(F_0(:,:)==4) = Soil_map_F_0(4,1);
F_0(F_0(:,:)==5) = Soil_map_F_0(5,1);
F_0(F_0(:,:)==6) = Soil_map_F_0(6,1);
F_0(F_0(:,:)==7) = Soil_map_F_0(7,1);
% F_0(F_0(:,:)<0) = nan;
F_0(F_0(:,:)<0) = 0;

%% ksat
ksat = SOIL;

ksat(ksat(:,:)==1) = Soil_map_ksat(1,1);
ksat(ksat(:,:)==2) = Soil_map_ksat(2,1);
ksat(ksat(:,:)==3) = Soil_map_ksat(3,1);
ksat(ksat(:,:)==4) = Soil_map_ksat(4,1);
ksat(ksat(:,:)==5) = Soil_map_ksat(5,1);
ksat(ksat(:,:)==6) = Soil_map_ksat(6,1);
ksat(ksat(:,:)==7) = Soil_map_ksat(7,1);
% ksat(ksat(:,:)<0) = nan;
ksat(ksat(:,:)<0) = 0;

%%%%%%% -------- Constraint at Impervious Areas -------- %%%%%%
ksat(idx_impervious) = 0; % This way, impervious areas have no infiltration capacity

%% psi
psi = SOIL;

psi(psi(:,:)==1) = Soil_map_psi(1,1);
psi(psi(:,:)==2) = Soil_map_psi(2,1);
psi(psi(:,:)==3) = Soil_map_psi(3,1);
psi(psi(:,:)==4) = Soil_map_psi(4,1);
psi(psi(:,:)==5) = Soil_map_psi(5,1);
psi(psi(:,:)==6) = Soil_map_psi(6,1);
psi(psi(:,:)==7) = Soil_map_psi(7,1);
% psi(psi(:,:)<0) = nan;
psi(psi(:,:)<0) = 0;

%% h_ef_w_0 - This is the initial water depth, you can enter a map of warm-up if you want
h_ef_w_0 = SOIL;

h_ef_w_0(h_ef_w_0(:,:)==1) = Soil_map_h_ef_w_0(1,1);
h_ef_w_0(h_ef_w_0(:,:)==2) = Soil_map_h_ef_w_0(2,1);
h_ef_w_0(h_ef_w_0(:,:)==3) = Soil_map_h_ef_w_0(3,1);
h_ef_w_0(h_ef_w_0(:,:)==4) = Soil_map_h_ef_w_0(4,1);
h_ef_w_0(h_ef_w_0(:,:)==5) = Soil_map_h_ef_w_0(5,1);
h_ef_w_0(h_ef_w_0(:,:)==6) = Soil_map_h_ef_w_0(6,1);
h_ef_w_0(h_ef_w_0(:,:)==7) = Soil_map_h_ef_w_0(7,1);
% h_ef_w_0(h_ef_w_0(:,:)<0) = nan;
h_ef_w_0(h_ef_w_0(:,:)<0) = 0;

%% roughness
roughness= LULC;

roughness(roughness(:,:)==0) = LULC_roughness(1,1);
roughness(roughness(:,:)==1) = LULC_roughness(2,1);
roughness(roughness(:,:)==2) = LULC_roughness(3,1);
roughness(roughness(:,:)==3) = LULC_roughness(4,1);
roughness(roughness(:,:)==4) = LULC_roughness(5,1);
roughness(roughness(:,:)==5) = LULC_roughness(6,1);
roughness(roughness(:,:)==6) = LULC_roughness(7,1);
roughness(roughness(:,:)==7) = LULC_roughness(8,1);
roughness(roughness(:,:)==8) = LULC_roughness(9,1);

%% h_0
h_0 = LULC;

h_0(h_0(:,:)==0) = LULC_h_0(1,1);
h_0(h_0(:,:)==1) = LULC_h_0(2,1);
h_0(h_0(:,:)==2) = LULC_h_0(3,1);
h_0(h_0(:,:)==3) = LULC_h_0(4,1);
h_0(h_0(:,:)==4) = LULC_h_0(5,1);
h_0(h_0(:,:)==5) = LULC_h_0(6,1);
h_0(h_0(:,:)==6) = LULC_h_0(7,1);
h_0(h_0(:,:)==7) = LULC_h_0(8,1);
h_0(h_0(:,:)==8) = LULC_h_0(9,1);

% %% Initial Data 
% input_table = readcell('Input_Main_Data_RTC.xlsx'); % Real Input_Data_RTC
% input_table(:,1) = [];
% input_table(:,2) = [];
% for i = 1:numel(input_table)
%     if ismissing(input_table{i})
%         input_table{i} = 0;
%     end
% end
% input_data = cell2mat(input_table);
 
Delta_x = input_data(59,1);
Delta_y = input_data(60,1);
slope_outlet = input_data(5,1);
%% Main Data of soil at watershed
% Changing names to match with the main file
n = roughness; dtheta = teta_sat - teta_i;

%% Mask in matrices to avoid numerical issues
mask = isnan(DEM);
% F0 constraint
F_0(mask) = 1e-6; % small number in mm
n(mask) = 1e-8; % small number in m^(1/3)/s
h_0(mask) = 1e-6; % small number in m^(1/3)/s
teta_sat(mask) = 1e-6; % small number in mm/h
teta_i(mask) = 1e-6; % small number in mm/h
psi(mask) = 1e-6;  % small number in cm3/cm3
ksat(mask) = 1e-6; % small number
dtheta(mask) = 1e-6; % small number
h_ef_w_0(mask) = 1e-6; % small number

%% 1.2 - Flow Direction, Slope and Direction Matrix %%%
 % coordinate system from left up corner (x -->) y (up-down)
[row, col] = find(DEM == min(min(DEM)));
coord_outlet = [row,col];
dim = size(DEM); rows = dim(1); cols = dim(2);

%%%% Flow Direction %%%%
[f_dir,idx_fdir] = FlowDirection(DEM,Delta_x,Delta_y,coord_outlet); % Flow direction matrix

%%%% Slope Calculation %%%%
[slope] = max_slope8D(DEM,Delta_x,Delta_y,coord_outlet,f_dir,slope_outlet);
idx_nan_fdir = isnan(slope);

%%%% Direction Matrix %%%%
Direction_Matrix_Zeros = sparse(-eye(length(f_dir(:)),length(f_dir(:)))); % Spase Matrix
[Direction_Matrix] = sparse(Find_D_Matrix(f_dir,coord_outlet,Direction_Matrix_Zeros));

f_dir(idx) = 0;
slope(idx) = 0;
Direction_Matrix(idx) = 0;