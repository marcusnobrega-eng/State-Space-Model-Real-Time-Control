%% Watershed Post-Processing
% 11/15/2022
% Developer: Marcus Nobrega
% Goal - Post Processing Results of Watershed

%% Plotting GIFs - Depths
h = figure;
axis tight manual % this ensures that getframe() returns a consistent size
filename = 'Depths_Dynamics.gif';
a_grid = resolution;
b_grid = resolution;
date_records = time_real(1); % Saving data
dmax = 0; infmax = 0;
for t = 1:size(d,2)
    % Time of Records in Date
    factor = record_time_maps/record_time_hydrographs;
    date_records = date_records + (factor)*record_time_hydrographs/24/60;
    % Draw plot
%     t_title = round(time_store(t)*time_step/60);
    t_title = date_records;
    z = reshape(d(:,t)/1000,[],size(DEM,2));
    idx = isnan(DEM);
    z(idx) = nan;
    dmax = max(dmax,z);
    xmax = length(z(1,:));
    xend = xmax;
    ymax = length(z(:,1));
    yend = ymax;
    xbegin = 1;
    ybegin = 1;
    % UTM Coordinates
    x_grid = [xbegin:1:xend]; y_grid = [ybegin:1:yend];
    z(z<=0)=nan;
    h_min = 0;
    F = z(y_grid,x_grid);
    zmax = max(max(d(~isnan(d))))/1000;
    if isempty(zmax) || isinf(zmax)
        zmax = 0.1;
    end
    map = surf(x_grid*a_grid,y_grid*b_grid,F);
    set(map,'LineStyle','none')
    axis([xbegin*a_grid xend*a_grid ybegin*b_grid yend*b_grid h_min zmax])
    title(datestr(t_title),'Interpreter','Latex','FontSize',12)
    view(0,90)
    caxis([h_min zmax]);
    colormap(jet)
    hold on
    k = colorbar ;
    ylabel(k,'Depths (m)','Interpreter','Latex','FontSize',12)
    xlabel(' x (m) ','Interpreter','Latex','FontSize',12)
    ylabel ('y (m) ','Interpreter','Latex','FontSize',12)
    zlabel ('Elevation (m)','Interpreter','Latex','FontSize',12)
    drawnow
    % Capture the plot as an image
    frame = getframe(h);
    im = frame2im(frame);
    [imind,cm] = rgb2ind(im,256);
    % Write to the GIF File
    if t == 1
        imwrite(imind,cm,filename,'gif', 'Loopcount',inf);
    else
        imwrite(imind,cm,filename,'gif','WriteMode','append');
    end
    hold off
end
clf

%% Plotting Infiltration
close all
h = figure;
axis tight manual % this ensures that getframe() returns a consistent size
filename = 'Infiltration_Dynamics.gif';
a_grid = resolution;
b_grid = resolution;
date_records = time_real(1); % Saving data
for t = 1:size(d,2)
    % Time of Records in Date
    factor = record_time_maps/record_time_hydrographs;
    date_records = date_records + (factor)*record_time_hydrographs/24/60; 
    % Draw plot
%     t_title = round(time_store(t)*time_step/60);
    t_title = date_records;
    z = reshape(I(:,t),[],size(DEM,2));
    infmax = max(infmax,z);
    idx = isnan(DEM);
    z(idx) = nan;
    xmax = length(z(1,:));
    xend = xmax;
    ymax = length(z(:,1));
    yend = ymax;
    xbegin = 1;
    ybegin = 1;
    % UTM Coordinates
    x_grid = [xbegin:1:xend]; y_grid = [ybegin:1:yend];
    z(z<=0)=nan;
    h_min = 0;
    F = z(y_grid,x_grid);
    zmax = max(max(I(~isnan(I))));
    if isempty(zmax) || isinf(zmax) || isnan(zmax)
        zmax = 0.1;
    end
    map = surf(x_grid*a_grid,y_grid*b_grid,F);
    set(map,'LineStyle','none')
    axis([xbegin*a_grid xend*a_grid ybegin*b_grid yend*b_grid h_min zmax])
    title(datestr(t_title),'Interpreter','Latex','FontSize',12)
    view(0,90)
    colorbar
    caxis([h_min zmax]);
    colormap(jet)
    hold on
    k = colorbar ;
    ylabel(k,'Infiltration (mm)','Interpreter','Latex','FontSize',12)
    xlabel(' x (m) ','Interpreter','Latex','FontSize',12)
    ylabel ('y (m) ','Interpreter','Latex','FontSize',12)
    zlabel ('Infiltration (mm)','Interpreter','Latex','FontSize',12)
    drawnow
    % Capture the plot as an image
    frame = getframe(h);
    im = frame2im(frame);
    [imind,cm] = rgb2ind(im,256);
    % Write to the GIF File
    if t == 1
        imwrite(imind,cm,filename,'gif', 'Loopcount',inf);
    else
        imwrite(imind,cm,filename,'gif','WriteMode','append');
    end
    hold off
end
clf
%% Max Depth and Inf max
ticksize = [0.04 0.03];
set(gcf,'units','inches','position',[0,1,6.5,6])
ax1 = subplot(2,2,1)
zzz = dmax;
zzz(zzz<0.001) = nan;
surf(x_grid*a_grid,y_grid*b_grid,zzz);
zmin = min(min(zzz)); zmax = max(max(zzz));
xmax = length(zzz(1,:));
xend = xmax;
ymax = length(zzz(:,1));
yend = ymax;
xbegin = 1;
ybegin = 1;
a_grid = resolution;
% UTM Coordinates
x_grid = [xbegin:1:xend]; y_grid = [ybegin:1:yend];
axis([xbegin*a_grid xend*a_grid ybegin*b_grid yend*b_grid zmin zmax])
set(gca, 'YDir','reverse')
xlabel('x (m)','interpreter','latex')
xlabel('y (m)','interpreter','latex')
set(gca,'ticklength',ticksize);
box on
view(0,90);
color = colormap(ax1,linspecer);
h = colorbar('northoutside');
h.Label.String = 'Max. Depth (m)';
h.Label.Interpreter = 'Latex';
hold on
set(gca,'fontsize',12);
hold off
ax2 = subplot(2,2,2);
zzz = infmax; % mm
zzz(zzz<=5) = nan;
zzz = zzz/1000; % m
surf(x_grid*a_grid,y_grid*b_grid,zzz);
set(gca,'ticklength',ticksize);
zmin = min(min(zzz)); zmax = max(max(zzz));
xmax = length(zzz(1,:));
xend = xmax;
ymax = length(zzz(:,1));
yend = ymax;
xbegin = 1;
ybegin = 1;
a_grid = resolution;
% UTM Coordinates
x_grid = [xbegin:1:xend]; y_grid = [ybegin:1:yend];
axis([xbegin*a_grid xend*a_grid ybegin*b_grid yend*b_grid zmin zmax])
set(gca, 'YDir','reverse')
xlabel('x (m)','interpreter','latex')
xlabel('y (m)','interpreter','latex')
view(0,90);
color = colormap(ax2,turbo);
h = colorbar('northoutside');
h.Label.String = 'Max. Soil Depth (m)';
h.Label.Interpreter = 'Latex';
hold on
set(gca,'fontsize',12);
box on
hold off

subplot(2,2,3)
% ETP + fG
factor = record_time_ETP/record_time_hydrographs;
for zzz = 1:(length(data_ETP(:,1)))
    ETP_daily(zzz,1) = ETP_saving((zzz-1)*factor + 1,1);
    f_g_daily(zzz,1) = sum(k_out*24.*idx_cells)/(sum(idx_cells)); % mm/day
end
plot(time_ETP,ETP_daily(1:length(time_ETP)),'linewidth',1,'color','black','marker','*');
hold on
plot(time_ETP,f_g_daily(1:length(time_ETP)),'linewidth',1,'color','red');
xlabel('Date','interpreter','latex');
ylabel('$E_{\mathrm{to}}$ and $f_g$ ($\mathrm{mm/day}$)','interpreter','latex');
set(gca,'fontsize',12);
set(gca,'ticklength',ticksize);
legend('$E_{to}$','$f_g$','interpreter','latex')
grid on
hold on

subplot(2,2,4)
tempmed = data_ETP(:,2);
tempmax = data_ETP(:,3);
tempmin = data_ETP(:,4);
windspeed = data_ETP(:,5);
relative_h = data_ETP(:,6)/100;
G = data_ETP(:,7);

% plot 
plot(time_ETP,tempmed,'linewidth',.5,'color','green','marker','*','linestyle','-');
hold on
plot(time_ETP,tempmax,'linewidth',.5,'color','green','marker','+','linestyle','-');
hold on
plot(time_ETP,tempmin,'linewidth',.5,'color','green','marker','x','linestyle','-');
hold on
plot(time_ETP,windspeed,'linewidth',.5,'color','blue','marker','.','linestyle','-');
hold on
ylabel('$t$ ($^{\circ}$  ($C$) or $u_2$ ($\mathrm{m/s}$)','interpreter','latex')
yyaxis right
set(gca,'ycolor','black')
ylabel('$u_r (-)$ or $g_r$ ($\mathrm{MJ m^{-2} day^{-1}}$)','interpreter','latex')
plot(time_ETP,relative_h,'linewidth',.5,'color','blue','marker','*','linestyle','--');
hold on
plot(time_ETP,G,'linewidth',.5,'color','red','marker','*');
set(gca,'fontsize',12);
set(gca,'ticklength',ticksize);
legend('$t_{\mathrm{med}}$','$t_{\mathrm{max}}$','$t_{\mathrm{min}}$','$u_{\mathrm{2}}$','$u_{\mathrm{r}}$','$g_r$','interpreter','latex')
grid on
exportgraphics(gcf,'Temperature_Chart.TIF','ContentType','image','Colorspace','rgb','Resolution',800)
%% Hydrographs - Elapsed Time
% Date Scale
close all
flag_date = 3; % 1 min, 2 hour, 3 day, 4 month
date_string = {'Elased time (min)','Elapsed time (h)','Elapsed time (days)','Elapsed time (months)'};
if flag_date == 1
    time_scale = 1;
elseif flag_date == 2
    time_scale = 1/60;
elseif flag_date == 3
    time_scale = 1/60/24;
else
    time_scale = 1/60/24/30;
end
%     t_title = time_real(t);
set(gcf,'units','inches','position',[0,1,6.5,4])
plot(time_records_hydrographs*time_scale,Qout_w(1:length(time_records_hydrographs)),'linewidth',2,'color','black');
xlabel(date_string(flag_date),'interpreter','latex');
ylabel('Flow discharge ($\mathrm{m^3/s}$)','interpreter','latex');
set(gca,'fontsize',14);
grid on
hold on
yyaxis right
set(gca,'ycolor','black');
plot(time_records_hydrographs*time_scale,Depth_out(1:length(time_records_hydrographs)),'linewidth',2,'color','black','LineStyle','--');
ylabel('Depth ($\mathrm{m}$)','interpreter','latex');
grid on
exportgraphics(gcf,'Hydrograph Watershed.pdf','ContentType','vector')

%% Rainfall and Flow Discharge
close all
set(gcf,'units','inches','position',[0,1,6.5,4])
plot(time_records_hydrographs*time_scale,Qout_w(1:length(time_records_hydrographs)),'linewidth',2,'color','black');
xlabel(date_string(flag_date),'interpreter','latex');
ylabel('Flow discharge ($\mathrm{m^3/s}$)','interpreter','latex');
set(gca,'fontsize',14);
grid on
hold on
yyaxis right
set(gca,'ycolor','black');
set(gca,'ydir','reverse')
rain_outlet = squeeze(i(pos,:));
plot(time_records_hydrographs*time_scale,rain_outlet(1:length(time_records_hydrographs)),'linewidth',2,'color','blue','LineStyle','-');
ylabel('Rainfall Intensity ($\mathrm{mm/h}$)','interpreter','latex');
ylim([0 300])
grid on
exportgraphics(gcf,'Hydrograph_Rainfall.pdf','ContentType','vector')

%% Hydrographs - Real-Time
% Date Scale
close all
set(gcf,'units','inches','position',[0,1,6.5,4])
plot(time_real,Qout_w(1:length(time_real)),'linewidth',2,'color','black');
xlabel('Date','interpreter','latex');
ylabel('Flow discharge ($\mathrm{m^3/s}$)','interpreter','latex');
set(gca,'fontsize',14);
grid on
hold on
yyaxis right
set(gca,'ycolor','black');
plot(time_real,Depth_out(1:length(time_real)),'linewidth',2,'color','black','LineStyle','--');
ylabel('Depth ($\mathrm{m}$)','interpreter','latex');
grid on
legend('Flow','Depth','interpreter','latex')
exportgraphics(gcf,'Hydrograph Watershed.pdf','ContentType','vector')

%% Rainfall and Flow Discharge - Real Time
set(gcf,'units','inches','position',[0,1,6.5,4])
plot(time_real,Qout_w(1:length(time_real)),'linewidth',2,'color','black');
xlabel('Date','interpreter','latex');
ylabel('Flow discharge ($\mathrm{m^3/s}$)','interpreter','latex');
set(gca,'fontsize',14);
grid on
hold on
yyaxis right
set(gca,'ycolor','black');
set(gca,'ydir','reverse')
rain_outlet = squeeze(i(pos,:));
plot(time_real,rain_outlet(1:length(time_real)),'linewidth',2,'color','blue','LineStyle','-');
ylabel('Rainfall Intensity ($\mathrm{mm/h}$)','interpreter','latex');
ylim([0 300])
grid on
exportgraphics(gcf,'Hydrograph_Rainfall.pdf','ContentType','vector')

% %% Rainfall and Flow Discharge - Original
% set(gcf,'units','inches','position',[0,1,6.5,4])
% plot(time_records_hydrographs*time_scale,Qout_w(1:length(time_records_hydrographs)),'linewidth',2,'color','black');
% xlabel(date_string(flag_date),'interpreter','latex');
% ylabel('Flow discharge ($\mathrm{m^3/s}$)','interpreter','latex');
% set(gca,'fontsize',14);
% grid on
% hold on
% yyaxis right
% set(gca,'ycolor','black');
% set(gca,'ydir','reverse')
% rain_outlet = squeeze(i(pos,:));
% plot(time_records_hydrographs*time_scale,rain_outlet(1:length(time_records_hydrographs)),'linewidth',2,'color','blue','LineStyle','-');
% ylabel('Rainfall Intensity ($\mathrm{mm/h}$)','interpreter','latex');
% ylim([0 300])
% grid on
% exportgraphics(gcf,'Hydrograph_Rainfall.pdf','ContentType','vector')

%% Climatologic Data Summary
% clear all;
% load workspace_3months_1dayleft.mat
close all
% Date ETP
factor = record_time_ETP/record_time_hydrographs;
for zzz = 1:(length(data_ETP(:,1)))
    ETP_daily(zzz,1) = ETP_saving((zzz-1)*factor + 1,1);
    f_g_daily(zzz,1) = sum(k_out*24.*idx_cells)/(sum(idx_cells)); % mm/day
end
set(gcf,'units','inches','position',[0,1,6.5,4])
plot(time_ETP,ETP_daily(1:length(time_ETP)),'linewidth',2,'color','black','marker','*');
hold on
plot(time_ETP,f_g_daily(1:length(time_ETP)),'linewidth',2,'color','red');
xlabel('Date','interpreter','latex');
ylabel('$E_{\mathrm{to}}$ and $f_g$ ($\mathrm{mm/day}$)','interpreter','latex');
set(gca,'fontsize',14);
grid on
hold on

yyaxis right
set(gca,'ycolor','black');
set(gca,'ydir','reverse')
rain_outlet = squeeze(i(pos,:));
plot(time_real,rain_outlet(1:length(time_real)),'linewidth',2,'color','blue','LineStyle','-');
ylabel('Rainfall Intensity ($\mathrm{mm/h}$)','interpreter','latex');
ylim([0 300])
grid on
legend('ETP','$f_g$','Rainfall','interpreter','latex')

exportgraphics(gcf,'Climatologic_Summary.pdf','ContentType','vector')

%% Rainfall + Infiltration at the Outlet - Real Time
% We want to calculate an average infiltration rate for the watershed
%%%% ---------- Average Infiltration Rate for the Maps time-step ----------
% f_rate = zeros(1,size(I,2));
% for zzz = 1:(size(I,2))
%     if zzz == 1
%         f_rate(1,zzz) = 0;
%     else
%         Vol_begin = sum(I(:,zzz-1))/(1000*1000*drainage_area/(resolution^2)); % mm per cell in average
%         Vol_end = sum(I(:,zzz))/(1000*1000*drainage_area/(resolution^2)); % mm per cell in average
%         if Vol_end ~= Vol_begin
%             ttt = 1;
%         end
%         f_rate(1,zzz) = (Vol_end - Vol_begin)/(record_time_maps/60); % mm/hr; % Soil flux
%     end
% end
% set(gcf,'units','inches','position',[0,1,6.5,4])
% plot(time_records_hydrographs*time_scale,Qout_w(1:length(time_records_hydrographs)),'linewidth',2,'color','black');
% xlabel(date_string(flag_date),'interpreter','latex');
% ylabel('Flow discharge ($\mathrm{m^3/s}$)','interpreter','latex');
% set(gca,'fontsize',14);
% grid on
% hold on
% yyaxis right
% set(gca,'ycolor','black');
% set(gca,'ydir','reverse')
% rain_outlet = squeeze(i(pos,:));
% plot(time_records_hydrographs*time_scale,rain_outlet(1:length(time_records_hydrographs)),'linewidth',2,'color','blue','LineStyle','-');
% ylabel('Rate ($\mathrm{mm/h}$)','interpreter','latex');
% hold on
% plot(time_records*time_scale,f_rate(1:length(time_records)),'linewidth',2,'color','red','LineStyle','-.');
% ylabel('Rate ($\mathrm{mm/h}$)','interpreter','latex');
% legend('Outlet Flow','Rainfall','Mean Soil Flux')
% ylim([ceil(min(f_rate)/5)*6 300])
% grid on
% exportgraphics(gcf,'Hydrograph_Effective_Rainfall.pdf','ContentType','vector')

%%%% ---------- Average Infiltration at Hydrograph Times ---------- %%%%
close all
set(gcf,'units','inches','position',[0,1,6.5,4])
plot(time_real,Qout_w(1:length(time_real)),'linewidth',2,'color','black');
xlabel('Date','interpreter','latex');
ylabel('Flow discharge ($\mathrm{m^3/s}$)','interpreter','latex');
set(gca,'fontsize',14);
grid on
hold on
yyaxis right
set(gca,'ycolor','black');
set(gca,'ydir','reverse')
rain_outlet = squeeze(i(pos,:));
plot(time_real,rain_outlet(1:length(time_real)),'linewidth',2,'color','blue','LineStyle','-');
ylabel('Rate ($\mathrm{mm/h}$)','interpreter','latex');
hold on
plot(time_real,f_rate(1:length(time_real)),'linewidth',2,'color','red','LineStyle','-.');
ylabel('Rate ($\mathrm{mm/h}$)','interpreter','latex');
legend('Outlet Flow','Rainfall','Mean Soil Flux','interpreter','latex')
ylim([ceil(min(f_rate)/5)*6 300])
grid on
exportgraphics(gcf,'Hydrograph_Effective_Rainfall_Detail.pdf','ContentType','vector')

%% Rainfall + Infiltration at the Outlet 
% We want to calculate an average infiltration rate for the watershed
%%%% ---------- Average Infiltration Rate for the Maps time-step ----------
% f_rate = zeros(1,size(I,2));
% for zzz = 1:(size(I,2))
%     if zzz == 1
%         f_rate(1,zzz) = 0;
%     else
%         Vol_begin = sum(I(:,zzz-1))/(1000*1000*drainage_area/(resolution^2)); % mm per cell in average
%         Vol_end = sum(I(:,zzz))/(1000*1000*drainage_area/(resolution^2)); % mm per cell in average
%         if Vol_end ~= Vol_begin
%             ttt = 1;
%         end
%         f_rate(1,zzz) = (Vol_end - Vol_begin)/(record_time_maps/60); % mm/hr; % Soil flux
%     end
% end
% set(gcf,'units','inches','position',[0,1,6.5,4])
% plot(time_records_hydrographs*time_scale,Qout_w(1:length(time_records_hydrographs)),'linewidth',2,'color','black');
% xlabel(date_string(flag_date),'interpreter','latex');
% ylabel('Flow discharge ($\mathrm{m^3/s}$)','interpreter','latex');
% set(gca,'fontsize',14);
% grid on
% hold on
% yyaxis right
% set(gca,'ycolor','black');
% set(gca,'ydir','reverse')
% rain_outlet = squeeze(i(pos,:));
% plot(time_records_hydrographs*time_scale,rain_outlet(1:length(time_records_hydrographs)),'linewidth',2,'color','blue','LineStyle','-');
% ylabel('Rate ($\mathrm{mm/h}$)','interpreter','latex');
% hold on
% plot(time_records*time_scale,f_rate(1:length(time_records)),'linewidth',2,'color','red','LineStyle','-.');
% ylabel('Rate ($\mathrm{mm/h}$)','interpreter','latex');
% legend('Outlet Flow','Rainfall','Mean Soil Flux')
% ylim([ceil(min(f_rate)/5)*6 300])
% grid on
% exportgraphics(gcf,'Hydrograph_Effective_Rainfall.pdf','ContentType','vector')

%%%% ---------- Average Infiltration at Hydrograph Times ---------- %%%%
% close all
% set(gcf,'units','inches','position',[0,1,6.5,4])
% plot(time_records_hydrographs*time_scale,Qout_w(1:length(time_records_hydrographs)),'linewidth',2,'color','black');
% xlabel(date_string(flag_date),'interpreter','latex');
% ylabel('Flow discharge ($\mathrm{m^3/s}$)','interpreter','latex');
% set(gca,'fontsize',14);
% grid on
% hold on
% yyaxis right
% set(gca,'ycolor','black');
% set(gca,'ydir','reverse')
% rain_outlet = squeeze(i(pos,:));
% plot(time_records_hydrographs*time_scale,rain_outlet(1:length(time_records_hydrographs)),'linewidth',2,'color','blue','LineStyle','-');
% ylabel('Rate ($\mathrm{mm/h}$)','interpreter','latex');
% hold on
% plot(time_records_hydrographs*time_scale,f_rate(1:length(time_records_hydrographs)),'linewidth',2,'color','red','LineStyle','-.');
% ylabel('Rate ($\mathrm{mm/h}$)','interpreter','latex');
% legend('Outlet Flow','Rainfall','Mean Soil Flux')
% ylim([ceil(min(f_rate)/5)*6 300])
% grid on
% exportgraphics(gcf,'Hydrograph_Effective_Rainfall.pdf','ContentType','vector')

%% Soil Content at Specifc Cell - Real Time
close all

% Time of Records in Date
for zzz = 1:(size(I,2))
    factor = record_time_maps/record_time_hydrographs;
    if zzz == 1
       date_records_maps(zzz,1) =  time_real(1); % Saving data
    else
       date_records_maps(zzz,1) = date_records_maps(zzz-1,1) + (factor)*record_time_hydrographs/24/60;  % Saving data
    end
end
cell_coord = pos; % If you want at the outlet, assume it as "pos"
set(gca,'ycolor','black');
plot(date_records_maps,I(pos,1:length(date_records_maps)),'linewidth',2,'color','black','LineStyle','-.');
ylabel('Depth ($\mathrm{mm}$)','interpreter','latex');
ylim([ceil(min(I(pos,:))/5)*4 ceil(max(I(pos,:)/5*8))]);
grid on
hold on
yyaxis right
set(gca,'ydir','reverse','ycolor','black')
% Rainfall Volume
rain_cumulative_pos = cumsum(i(pos,:))*record_time_hydrographs/60;
% ETP
etp_cumulative_pos = cumsum(ETP_saving/24)*record_time_hydrographs/60;
plot(time_real,rain_cumulative_pos(1,1:length(time_real)),'linewidth',2,'color','blue','linestyle','--');
hold on
plot(time_real,etp_cumulative_pos(1:length(time_real),1),'linewidth',2,'color','green','linestyle','-.');
ylim([ceil(min(rain_cumulative_pos)/5)*4 ceil(max(rain_cumulative_pos/5*12))]);
ylabel('Cumulative Rainfall and ETP ($\mathrm{mm}$)','interpreter','latex')
xlabel('Date','interpreter','latex');
lgd = legend('Infiltrated Depth','Cumulative Rainfall','Cumulative ETP','location','northoutside');
lgd.NumColumns = 3;
exportgraphics(gcf,'Infiltrated_Depth.pdf','ContentType','vector')

%% Soil Content at Specifc Cell
% close all
% cell_coord = pos; % If you want at the outlet, assume it as "pos"
% set(gca,'ycolor','black');
% plot(time_records*time_scale,I(pos,1:length(time_store)),'linewidth',2,'color','black','LineStyle','-.');
% ylabel('Depth ($\mathrm{mm}$)','interpreter','latex');
% ylim([ceil(min(I(pos,:))/5)*4 ceil(max(I(pos,:)/5*8))]);
% grid on
% hold on
% yyaxis right
% set(gca,'ydir','reverse','ycolor','black')
% % Rainfall Volume
% rain_cumulative_pos = cumsum(i(pos,:))*record_time_hydrographs/60;
% % ETP
% etp_cumulative_pos = cumsum(ETP_saving/24)*record_time_hydrographs/60;
% plot(time_records_hydrographs*time_scale,rain_cumulative_pos,'linewidth',2,'color','blue','linestyle','--');
% hold on
% plot(time_records_hydrographs*time_scale,etp_cumulative_pos,'linewidth',2,'color','green','linestyle','-.');
% ylim([ceil(min(rain_cumulative_pos)/5)*4 ceil(max(rain_cumulative_pos/5*12))]);
% ylabel('Cumulative Rainfall and ETP ($\mathrm{mm}$)','interpreter','latex')
% xlabel(date_string(flag_date),'interpreter','latex');
% lgd = legend('Infiltrated Depth','Cumulative Rainfall','Cumulative ETP','location','northoutside');
% lgd.NumColumns = 3;
% exportgraphics(gcf,'Infiltrated_Depth.pdf','ContentType','vector')