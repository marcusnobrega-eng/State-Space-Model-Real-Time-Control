%% Genetic Algorithm Optimization Approach
% 8/1/2021
% Developer: Marcus Nobrega
% Goal: The Objective Function of the MPC controller
% Notes: You can write an objective function as a non-linear combination
% within control deviations (dU), water depths in the reservoir (x_r), and
% maximum water levels in the channel and in the reservoir

function [OF] = Optimization_Function(U)
global Qout_w Qout_w_horizon steps_control_horizon steps_horizon time_step n_steps Control_Vector Nvars i_reservoir h_c_0 h_r_t ur_eq_t i_reservoir_horizon previous_control average variance slope_outlet tfinal record_time_maps ETP new_timestep Control_Interval Control_Horizon Prediction_Horizon g Cd flag_r number_of_orifices D l b relative_hmin Cds Lef hs porosity orifice_height x_length y_length roughness segments slope slope_outlet_channel max_iterations max_fun_eval n_randoms flag_c flag_r hmin s h_end slope_outlet_channel n_channel
%% O.F parameters
ro_u = 1e2; % Weight on control signal variation
ro_x = 0; % Weight on states variation (in this case, water level)
ro_r_hmax = 1e6;  % Weight on maximum height in the reservoir

% ro_c = 1e7; % Weight on maximum height in the channel
% ro_HI = 1e-1; % Weight of Human Instability Index
% y_ref = 1.8; % Reference water level in the channel(maximum)

max_res_level = 4.4; % 4.4 m is the maximum water level in the reservoir

%%%% Function %%%%%
%   ro_u*dU*dU' + ro_x*x_r^T*x_r + ro_r_hmax*(max(max_hc - y_ref,0)) + ro_c*(max(max_hr - max_res_level,0));
% dU = [du(1), du(2) ... du(Np-1)]'
% du is delta U. For instance: du(t) = u(t+1) - u(t)
u = zeros(steps_horizon,1);
dU = zeros(steps_horizon-1,1);
%% Disagregating the Control into the time-steps
for i=1:(steps_horizon)
    % Disagregating the control U into u
    idx = find(Control_Vector < i,1,'last'); % Position in U
    u(i,1) = U(idx);
    if i == 1
        dU(i) = u(i) - previous_control;
    else
        dU(i,1) = u(i) - u(i-1);
    end
end
%% Call Scripts for the Reservoir and for the Channel
% Calls the Reservoir Plant
[x_r,out_r] = reservoir_dynamics(Qout_w,time_step,u,variance,average);
max_hr = max(x_r); % Max water level in the reservoir in meters
% ------- If you don't want to model the channel, you should deactivate below
% [~,h_c] = channel_dynamics(out_r,time_step,h_c_0);
% max_hc = max(max(h_c)); % Max water level in the channel
%% Objective Function
% Original - {deviations in control} + {deviations in res. w. level) +
% {deviations in channel w.l) + penalizations in res and chan w.l
% Changed - We take out channel constraint and include a penalization in
% flows larger than a threshold
q_max_star = 4; % Threshold for relatively small events in m3/s
q_max_star_star = 4; % Threshold for relatively large events in m3/s
alfa_p = 0.5; % Peak flow factor

if max(Qout_w_horizon) < q_max_star % Release the flows, if required, but not so much
    max_outflow = alfa_p*max(Qout_w_horizon); % m3/s - we are assuming we reduce at least alfa_p of all flows
    ro_outflow = 1e8; % Weight on maximum reservoir outflow in this case
else
    max_outflow = q_max_star_star; % m3/s - We want to minimize as best as we can
    ro_outflow = 1e6; % Weight on maximum reservoir outflow    
end

% --- Previous % ---
% [OF] = ro_u*norm(dU,2)^2 + ro_x*norm(x_r,2)^2 + ro_c*(max(max_hc - y_ref,0)) + ro_r_hmax*(max(max_hr - max_res_level,0));
% ---- Changed ---- %
[OF] = ro_u*norm(dU,2)^2 + ro_x*norm(x_r,2)^2 + ro_r_hmax*(max(max_hr - max_res_level,0)) + ro_outflow*sum(max(out_r - max_outflow,0));
% ---- Changed with Human Instability Index in the Channel ---- %
% [OF] = ro_u*norm(dU,2)^2 + ro_x*norm(x_r,2)^2 + ro_r_hmax*(max(max_hr - max_res_level,0)) + ro_outflow*max(max((out_r - max_outflow),0)) + ro_HI*max(0,instability);
end