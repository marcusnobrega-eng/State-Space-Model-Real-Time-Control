%% Watershed Finite-Difference Scheme Model
% Developer: Marcus Nobrega
% 4/23/2021
% Goal: Define a Model that Calculates the flow in the Outlet of a
% Watershed in a Matrix Fashion
% Observation: We added k_out to consider ground water

function [F_d,h_ef_w,inflows] = wshed_matrix(d_0,h_0,inflows,time_step,Direction_Matrix,i_0,ksat,psi,dtheta,I_0,Lambda,Delta_x,Delta_y,ETP,idx_fdir,k_out)
    % Faster way    
    % Solving the discretized water balance in each cell
    % d(k+1) = d(k) + T*(i(k) + (qin - qout) - inf)
    if max(inflows) <= 1e-2 % mm/hr
    % No need for matrix multiplication because max inflow is very low
        h_ef_w = max(d_0 + time_step/3600*(i_0 - ETP/24 - k_out - min(i_0 + d_0/(time_step/3600),ksat.*(1 + ((psi + d_0).*dtheta)./I_0))),0);   
        F_d = max(I_0 + (i_0 - ETP/24 - k_out)*time_step/3600 + d_0 - h_ef_w,5); % Stored depth in mm for (k+1); (assuming a min of 5 mm)   
    else
        delta_q = (Direction_Matrix)*(inflows).*idx_fdir; % This can be time expensive
        h_ef_w = max(d_0 + time_step/3600*(delta_q + i_0 - ETP/24 - k_out - min(d_0/(time_step/3600) + i_0 - ETP/24 - k_out,ksat.*(1 + ((psi + d_0).*dtheta)./I_0))),0); % took out d_t/time_step        
        F_d = max(I_0 + (i_0 - ETP/24 - k_out + delta_q)*time_step/3600 + d_0 - h_ef_w,5); % Stored depth in mm for (k+1); (assuming a min of 5 mm)  
    end
    inflows = non_lin_reservoir(Lambda,h_ef_w,h_0,Delta_x,Delta_y); % flow_t = flow(k+1) (outflow from each cell)
    if min(min(h_ef_w)) < 0
        error('Reduce the time-step.') % Depths are becoming negative - instability
    end    
end