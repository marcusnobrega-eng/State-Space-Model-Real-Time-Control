%% Main File - MPC solver for the Watershed + Reservoir + Channel system
% Developer: Marcus Nobrega Gomes Junior
% 8/1/2021
% Main Script
% Goal: Create the main file containing:
% a) Watershed Model
% b) Connection between the Optimization Function and the Solvers
% c) Plant Models of the Reservoir and Channel
% d) Saving final results
clear all
clc
global Qout_w Qout_w_horizon steps_control_horizon steps_horizon time_step n_steps Control_Vector Nvars i_reservoir h_c_0 h_r_t ur_eq_t i_reservoir_horizon previous_control average variance slope_outlet tfinal record_time_maps ETP new_timestep Control_Interval Control_Horizon Prediction_Horizon g Cd flag_r number_of_orifices D l b relative_hmin Cds Lef hs porosity orifice_height x_length y_length roughness segments slope slope_outlet_channel max_iterations max_fun_eval n_randoms flag_c flag_r hmin s h_end slope_outlet_channel n_channel a_noise b_noise ur_eq hr_eq flag_save_data m L Cd_HI u B pperson pfluid h_max_channel L_channel
%% INPUT DATA %%

input_table = readcell('Input_Main_Data_RTC.xlsx'); % Reading Input data from Excel
input_table(:,1) = [];
input_table(:,2) = [];
for i = 1:numel(input_table)
    if ismissing(input_table{i})
        input_table{i} = 0;
    end
end
input_data = cell2mat(input_table);
flag_reservoir_wshed = input_data(61,1); % If == 1, we subtract the reservoir area * i in the outlet flow

% 1) Running Control
record_time_maps = input_data(2,1);
tfinal = input_data(3,1);
% 2) Watershed Data
slope_outlet = input_data(5,1);
ETP = input_data(6,1);
time_step = input_data(7,1);
% 3) Reservoir Data
g = input_data(9,1);
Cd = input_data(10,1);
flag_r = input_data(11,1);
flag_c = input_data(12,1);
number_of_orifices = input_data(13,1);
D = input_data(14,1);
l = input_data(15,1);
b = input_data(16,1);
relative_hmin = input_data(17,1);
Cds = input_data(18,1);
Lef = input_data(19,1);
hs = input_data(20,1);
porosity = input_data(21,1);
orifice_height = input_data(22,1);
ur_eq_t = input_data(23,1);
h_r_t = input_data(24,1);
hmin = input_data(25,1);

% 4) Channel Data
x_length = input_data(28,1);
y_length = input_data(29,1);
n_channel = input_data(30,1);
segments = input_data(31,1);
h_end = input_data(32,1);
s = input_data(33,1);
slope_outlet_channel = input_data(34,1);
h_c_0 = zeros(segments,1);

% 5) MPC Control
new_timestep = input_data(36,1);
Control_Interval = input_data(37,1);
Control_Horizon = input_data(38,1);
Prediction_Horizon = input_data(39,1);
% 5.1) Interior Point Solver
max_iterations = input_data(40,1);
max_fun_eval = input_data(41,1);
%%%% Range of the Initial Values %%%%
a_noise = input_data(42,1);
b_noise = input_data(43,1);
% 5.1.1) Randoms
n_randoms = input_data(44,1);
% Initial Equilibrium Points for the Reservoir
ur_eq = input_data(45,1);
hr_eq = input_data(46,1);
% Data
flag_save_data = input_data(47,1);

%Human instability
m = input_data(49,1); %m
L = input_data(50,1); %m
Cd_HI = input_data(51,1); %adm
u = input_data(52,1); %adm
B = input_data(53,1); %m
pperson = input_data(54,1); %Kg/m³
pfluid = input_data(55,1); %Kg/m³
h_max_channel = input_data(56,1); %m
L_channel = input_data(57,1); %m
record_time_hydrographs = input_data(62,1); % Minutes; % We are assuming the same as the rainfall (Minutes)
record_time_ETP = 1440; % Minutes
%% 1.0 - Defining simulation duration
% tifnal is the final minute where the simulation is performed. It has to
% be larger than the rainfall duration in order to make sure the hydrograph
% is propagated properly
time = (0:time_step:tfinal*60)/60; % time vector in min
n_steps = length(time); % number of steps
number_of_records = floor((n_steps-1)*time_step/(record_time_maps*60)); % number of stored data (size of the vector)
number_of_records_hydrographs = floor((n_steps-1)*time_step/(record_time_hydrographs*60)); % number of stored data (size of the vector)
time_records = [0:record_time_maps:tfinal]; % time in minutes
time_records_hydrographs = [0:record_time_hydrographs:tfinal]; % time in minutes
time_records_ETP = [0:record_time_ETP:tfinal]; % time in minutes
% vector to store data
time_store = time_records*60./time_step; % number of steps necessary to reach the recording vector
time_store(1) = 1; % the zero is the firt time step

% Hydrographs and Rainfall
time_store_hydrographs = time_records_hydrographs*60./time_step; % number of steps necessary to reach the recording vector
time_store_hydrographs(1) = 1;

% ETP
time_store_ETP = time_records_ETP*60./time_step; % number of steps necessary to reach the recording vector
time_store_ETP(1) = 1;
%% 2.0 - Watershed Preprocessing
% Call sub - Here we read all watershed information
Watershed_Physics
%% 3.0 - Calculating Flow Constants
resolution = (Delta_x + Delta_y)/2; % Average cell resolution
Lambda = (resolution)*(1./n).*slope.^(0.5); % Lumped hydraulic properties for k = 1
zzz = isinf(DEM) + isnan(DEM); % Logical array with where infs or nans occur
idx = zzz > 0; % Logical array where zzz > 0
Lambda(idx) = 0; % Values with zzz > 0 have no hydraulic properties
Lambda = real(Lambda);
Lambda = Lambda(:); % Concatenated Lambda resultin in a 1-D array
%% 4.0 - Preallocations
d = zeros(numel(DEM),length(time_store)); flow_t = d; I = d; % zeros
flow_outlet = zeros(length(time_store),1);
h_ef_w(:,1) = h_ef_w_0(:);
% Output function of 1 watershed
Qout_w = zeros(length(time_store_hydrographs),1); % Catchment Outflow (cms)
Qout_w(1,1) = flow_outlet(1,1);
% ETP saving
ETP_saving = zeros(length(time_store_hydrographs),1); % Catchment Outflow (cms)
% Position in the vector
% Given a 2-D position (row,col), where row is the row of the outlet and col, the
% collumn of the outlet, we can find pos, such that:
% pos = (y1-1)*rows + x1;
pos = (col-1)*rows + row; % Outlet vector containing the position of the outlet
Depth_out = zeros(length(time_store_hydrographs),1);
Depth_out(1,1) = h_ef_w(pos,1);
f_rate = zeros(1,length(time_store_hydrographs));
f_rate(1,1) = 0;
% Inflow_Matrix
Inflow_Matrix = Direction_Matrix;
Inflow_Matrix(Inflow_Matrix == -1) = 0;
%% 5.0 Evapotranspiration
neg_DEM = DEM < 0;
neg_LULC = LULC < 0;
neg_SOIL = SOIL < 0;
inf_nan_MAPS = isinf(DEM) + isnan(DEM) + neg_DEM + isnan(LULC) + isnan(SOIL) + neg_LULC + neg_SOIL + isinf(LULC) + isinf(SOIL); % Logical array
idx = inf_nan_MAPS > 0;
DEM_1(idx) = 1e-8; % Small value to allow matrix operations
idx_cells = DEM >= 0;
idx_cells = double(idx_cells(:));
% Read ETP data
data_ETP = xlsread('ETP_input.xlsx'); % Read ETP Data
% 1 - date, 2 - Tmed, 3 - Tmax, 4 - Tmin - 5 Vel(2m), 6 - (UR), 7 - G
%%%%% ----- General data of ETP %%%%%% -------
alfa_albedo_input = 0.23; % Assumed value
Krs = 0.16; % Local Coefficient for the determination of Solar Radiation (fixed in 0.16 for continental regions and 0.19 for coastal areas)
lat = -23.62;% centroid latitude of the watershed (decimal degree)
G_input = 0.6; % MJ/(m2.day)

% Converting time
time_ETP = data_ETP(:,1);
time_ETP = datetime(time_ETP, 'ConvertFrom','excel', 'Format','dd-MMM-uuuu');
% Initial Data
Temp = data_ETP(1,2);
Temp_max = data_ETP(1,3);
Temp_min = data_ETP(1,4);
U_2_input = data_ETP(1,5);
U_R_input = data_ETP(1,6);
Day_year = day(time_ETP(1,1),'dayofyear');
% ETP
[ETP] = Evapotranspiration(DEM,Temp,Temp_max,Temp_min,Day_year,lat,U_2_input,U_R_input,Krs,alfa_albedo_input,G_input);
ETP = ETP(:); % So far, ETP is uniform in space and variable in time
ETP_saving(1,1) = ETP(pos);
% ETC = Kc*ETP; Crop Evapotranspiration
%% 6.0 - Groundwater Volume (SWMW like approach)
% Replenishing Coefficient
kr = (1/75*(sqrt(ksat/25.4))); % Replenishing rate (1/hr) (Check Rossman, pg. 110)
Tr = 4.5./sqrt(ksat/25.4); %  Recovery time (hr) Check rossman pg. 110
Lu = 4.*sqrt(ksat/25.4); % Inches - Uppermost layer of the soil
Lu = Lu*2.54/100; % Meters
k_out = (teta_sat - teta_i).*kr.*Lu*1000; % Rate of replenishing exfiltration from the saturated zone during recoverying times (mm/hr)
k_out = k_out(:); % Rate of aquifer replenishing (mm/hr)
%% 7.0 - Rainfall Model
step_rainfall = input_data(62,1); % Minutes
[i,i_0,time_real] = rainfall_model(rows,cols,time_store_hydrographs,number_of_records_hydrographs,record_time_hydrographs,step_rainfall); % Results in 3-D arrays
i = reshape(i,dim(1)*dim(2),length(time_store_hydrographs)); % Results in concatenated 2-D array
% Check Rainfall and ETP Consistency
Day_year_rainfall = day(time_real(1,1),'dayofyear');
if Day_year ~= Day_year_rainfall
    error('Please make sure your rainfall dates and ETP dates match at least for the day.')
end
%% 8.0 - Array Concatenation
% %%%% Creating concatenated 1D arrays %%%
n = n(:);
h_0 = h_0(:);
ksat = ksat(:);
dtheta = dtheta(:);
F_d = F_0(:);
psi = psi(:);
% Initial Inflow
[inflows] = non_lin_reservoir(Lambda,h_ef_w,h_0,Delta_x,Delta_y);
flow_outlet(1,1) = sum(inflows(pos)*(Delta_x*Delta_y)/(1000*3600)); % Initial Outflow
t_store = 1;

% Making Zeros at Outside Values
i_0 = i_0(:).*idx_cells;
ETP = ETP.*idx_cells;
ksat = ksat(:).*idx_cells;
h_ef_w = h_ef_w.*idx_cells;
psi = psi.*idx_cells;
%ETP = input_data(6,1); % ETP constante no espaço e tempo
% Watershed Area
drainage_area = sum(sum(double(DEM>0)))*resolution^2/1000/1000; % area in km2
%% 9.0 - Solving the Water Balance Equations for the Watersheds
% Read Reservoir Area
hmax = 6.9; % Maximum reservoir area (You've got to enter it). The rationale with this is that rainfall occurs in the top area of the reservoir
[~,Area] = reservoir_area(hmax,0); %
tic % Starts Counting Time
k = 0;
I_previous = F_d;
error = zeros(n_steps,1);
while k <= (n_steps - 1)
    k = k + 1;
    % Rainfall Input
    z = find(time_store_hydrographs <= k, 1,'last' ); % Position of rainfall
    i_0 = i(:,z).*idx_cells; % Initial Rainfall for the next time-step
    % Determine the Water Surface Elevation Map
    wse = DEM + 1/1000*reshape(h_ef_w,[],size(DEM,2));
    % Call Flow Direction Sub
    [f_dir,idx_fdir] = FlowDirection(wse,Delta_x,Delta_y,coord_outlet); % Flow direction matrix
    % Call Slope Sub
    [slope] = max_slope8D(wse,Delta_x,Delta_y,coord_outlet,f_dir,slope_outlet); % wse slope
    % Call Dir Matrix
    [Direction_Matrix] = sparse(Find_D_Matrix(f_dir,coord_outlet,Direction_Matrix_Zeros));
    % Calculate Lambda
    Lambda = (resolution)*(1./n).*slope(:).^(0.5); % Lumped hydraulic properties
    % Calculate ETP if the ETP time-step is reached
    % Saving hydrographs and depths with user defined recording time-step
    if k == 1
    elseif find(time_store_ETP == k) > 0 % Typically - Daily
        t_store_ETP = find(time_store_ETP == k); % Time that is being recorded in min
        % Tmed, Tmax, Tmin
        Temp = data_ETP(t_store_ETP,2); % Average
        Temp_max = data_ETP(t_store_ETP,3); % Max
        Temp_min = data_ETP(t_store_ETP,4); % Min
        U_2_input = data_ETP(t_store_ETP,5); % Vel at 2m from surface
        U_R_input = data_ETP(t_store_ETP,6); % Relative humidity in percentage
        Day_year = day(time_ETP(t_store_ETP,1),'dayofyear'); % Convert day in day of the year
        % Call ETP function
        [ETP] = Evapotranspiration(DEM,Temp,Temp_max,Temp_min,Day_year,lat,U_2_input,U_R_input,Krs,alfa_albedo_input,G_input);
        ETP = ETP(:); % Concatenate ETP
    end
    % Call the Watershed Matrix Model
    [F_d,h_ef_w,inflows] = wshed_matrix(h_ef_w,h_0,inflows,time_step,Direction_Matrix,i_0,ksat,psi,dtheta,F_d,Lambda,Delta_x,Delta_y,ETP,idx_fdir,k_out);
    % Saving variables with user defined recording time-step
    if k == 1
        % Do nothing, it is already solved, we just have to save the data
        % for the next time-step
    elseif find(time_store == k) > 0
        t_store = find(time_store == k); % Time that is being recorded in min
        d(:,t_store) = h_ef_w(:); % Depths in mm
        I(:,t_store) = (F_d); % stored depth in mm
        if max(max(d)) > 500
            ttt = 1;
        end
    end

    % Saving hydrographs and depths with user defined recording time-step
    if k == 1
        % Do nothing, it is already solved, we just have to save the data
        % for the next time-step
        t_store_hydrographs= 1;
    elseif find(time_store_hydrographs == k) > 0
        t_store_hydrographs = find(time_store_hydrographs == k); % Time that is being recorded in min
        if flag_reservoir_wshed == 1
            Qout_w(t_store_hydrographs,1) = sum(inflows(pos)*(Delta_x*Delta_y)/(1000*3600)) - Area*i_0(1,1)/1000/3600; % Outflow (cms)
            Depth_out(t_store_hydrographs,1) = 1/1000*h_ef_w(pos); % m
        else
            Qout_w(t_store_hydrographs,1) = sum(inflows(pos)*(Delta_x*Delta_y)/(1000*3600)); % Outflow - Area * i (cms)
            Depth_out(t_store_hydrographs,1) = 1/1000*h_ef_w(pos); % m
            %Qout_w(k,1) = sum(inflows(pos)*(Delta_x*Delta_y)/(1000*3600)); % Outflow - Area * i (cms)
        end
        ETP_saving(t_store_hydrographs,1) = ETP(pos); % ETP value in mm/day but at rain and flow time-step
        % Average Infiltration
        I_actual = F_d; % mm in each cell
        Vol_begin = sum(I_previous.*idx_cells)/(1000*1000*drainage_area/(resolution^2)); % mm per cell in average
        Vol_end = sum(I_actual.*idx_cells)/(1000*1000*drainage_area/(resolution^2)); % mm per cell in average
        f_rate(1,t_store_hydrographs) = (Vol_end - Vol_begin)/(record_time_hydrographs/60); % mm/hr; % Soil flux
        I_previous = I_actual;
    end

    perc = k/(n_steps-1)*100;
    perc_______qoutw______depthw___infexut___timeremain____ETP = [perc,Qout_w(t_store_hydrographs,1),Depth_out(t_store_hydrographs,1),I(pos,t_store),toc*100/perc/3600,ETP(pos)] % Showing the depths at the outlet and the percentage of the calculations a

    % Check if a Steady Dry Condition is Reached
    if max(h_ef_w) == 0 && max(F_d) == 5
        z = find(time_store_hydrographs <= k, 1,'last' ); % Position of rainfall
        zz = find(i(pos,z:end) > 0,1,'first') + z - 1;
        k = zz*step_rainfall*60/time_step - 2;
        t_new = find(time_store_ETP <=k,1,'last'); % Time that is being recorded in min
        % Tmed, Tmax, Tmin
        Temp = data_ETP(t_new,2); % Average
        Temp_max = data_ETP(t_new,3); % Max
        Temp_min = data_ETP(t_new,4); % Min
        U_2_input = data_ETP(t_new,5); % Vel at 2m from surface
        U_R_input = data_ETP(t_new,6); % Relative humidity in percentage
        Day_year = day(time_ETP(t_new,1),'dayofyear');
        % Call ETP function
        [ETP] = Evapotranspiration(DEM_1,Temp,Temp_max,Temp_min,Day_year,lat,U_2_input,U_R_input,Krs,alfa_albedo_input,G_input);
        ETP = ETP(:);
        I_previous = F_d;
        ETP_saving(t_new+1,1) = ETP(pos); % ETP value in mm/day
    end

    %%% ------------- Mass Balance Routine  ------------------- %%%
    rain = i_0(pos); % mm/h
    etp_rate = ETP(pos)/24 ; % mm/h
    exf = sum(sum(k_out))/(sum(sum(double(idx_cells)))); % average k_out for all catchment (mm/h)
    Q = sum(inflows(pos)*(Delta_x*Delta_y)/(1000*3600)); % m3/s of outflow
    S_t_1 = drainage_area*1/1000*sum(F_d.*idx_cells)/(1000*1000*drainage_area/(resolution^2)); % m3
    S_t = S_t_1;
    % Mathematical Background for Error Evaluation
    % i*dt = Q*dt + ETP*dt - Exf*dt - DS (Mass Balance Equation)
    % DS = [(Q + (ETP - Exf - i)A]dt (Storage Variation = S(t+1) - S(t))
    % S(t+1) - S(t) = [Q + (ETP - Exf - i)A]dt
    % Mass Balance Error
    % e1 = S(t+1) - S(t) (error 1)
    % e2 = (Q + ETP - Exf - i)dt (error 2)
    % error = e1 - e2 ; this has to be 0
    e1 = S_t_1 - S_t;
    e2 = time_step*(Q + 1/1000/3600*(etp_rate - exf - rain)*drainage_area); % m3
    error(k) = e1 - e2;
end
watershed_runningtime = toc/60; % Minutes

%% 10.0 - Watershed Post-Processing
% Call sub - Generate GIFs, Hydrographs, and so on
watershed_post_processing
%% 11.0 Modeling Reservoir + Channel Dynamics
% Pre allocating arrays
h_r = zeros(n_steps,1); % Depth in the reservoir (m)
i_reservoir = zeros(n_steps,1);
u_begin = ur_eq_t; % Initial control law
i_outlet = i(pos,:)'; % Rainfall in the outlet
% Evaporation in the Reservoir (timeseries or constant value)
E = input_data(26,1);
% Net Rainfall For-Loop
for k =1:(n_steps-1)
    z = find(time_store_hydrographs <= k,1,'last'); % Be careful here
    i_reservoir(k,1) = i_outlet(z,1); % Initial Net Rainfall for the next time-step
end
% We recommend saving the workspace such as
save('workspace_waterhsed');
%% 12.0 Agregating time-step to increase speed
% Agregating the Inflow to a larger time-step
% You can either enter with your observed outflow from the watershed and
% observed rainfall or use the ones calculated previously.
% To gain velocity, we can enter these values loading these files below:
global Qout_w Qout_w_horizon steps_control_horizon steps_horizon time_step n_steps Control_Vector Nvars i_reservoir h_c_0 h_r_t ur_eq_t i_reservoir_horizon previous_control average variance slope_outlet tfinal record_time_maps ETP new_timestep Control_Interval Control_Horizon Prediction_Horizon g Cd flag_r number_of_orifices D l b relative_hmin Cds Lef hs porosity orifice_height x_length y_length roughness segments slope slope_outlet_channel max_iterations max_fun_eval n_randoms flag_c flag_r hmin s h_end slope_outlet_channel n_channel
% Here we close everything and start loading watershed data
clear all
close all
load workspace_waterhsed.mat % Workspace with all data generated

% Downscalling Qout to model's time-step that might be different
x = time_store_hydrographs; % low sampled data
xq = time*60/time_step; % high sampled data
v = Qout_w; % result from low sampled data
vq2 = interp1(x,v,xq,'pchip'); % high sampled data interpolation
% plot(x,v,'o',xq,vq2,':.');
% shg
Qout_w = vq2; % Downscalled Data
E = input_data(26,1); % Evaporation Data
%%%% Net Rainfall i'(k)
i_reservoir = i_reservoir - E/24; % Rainfall intensity - Evaporation Intensity (mm/h)
% All of this previously done is to to avoid to run the watershed model, but
% you can run, of course, or you can also input it from HEC-HMS or other
% model

%%%% Agregating Time-Steps to the new_timestep for the reservoir model %%%%
flow_timestep = time_step;
inflow_timesteps = n_steps; % Number of time-steps using the watershed time-step
n_steps = (n_steps-1)*time_step/new_timestep; % adjusting the new number of time-steps
Qout_w_disagregated = Qout_w';
agregation_step = new_timestep/time_step; % number of time-steps in on agregation time-step

% Preallocating Arrays
n_steps_disagregation = (inflow_timesteps/agregation_step-1);
flow_agregated = zeros(n_steps_disagregation,1);
i_reservoir_agregated = zeros(n_steps_disagregation,1);

% Disagregating or Agreagating flows and rainfall
for i = 1:n_steps_disagregation
    if new_timestep >= time_step
        flow_agregated(i,1) =  mean(Qout_w_disagregated(1 + (i-1)*agregation_step:i*agregation_step,1));
        i_reservoir_agregated(i,1) = mean(i_reservoir(1 + (i-1)*agregation_step:i*agregation_step,1));
    else
        flow_agregated(i,1) =  Qout_w_disagregated(1 + floor((i-1)*agregation_step):ceil(i*agregation_step));
        i_reservoir_agregated(i,1) = i_reservoir(1 + floor((i-1)*agregation_step):ceil(i*agregation_step));
    end
end

% Defining updated outflows from the watershed, rainfall intensity and
% time_step
Qout_w = flow_agregated;
i_reservoir = i_reservoir_agregated;
time_step = new_timestep; 

%% 13.0 Calling MPC control
% Let's clear variables we don't use to avoid computational burden
clearvars -except Qout_w Qout_w_horizon steps_control_horizon steps_horizon time_step n_steps Control_Vector Nvars i_reservoir h_c_0 h_r_t ur_eq_t i_reservoir_horizon previous_control average variance slope_outlet tfinal record_time_maps ETP new_timestep Control_Interval Control_Horizon Prediction_Horizon g Cd flag_r number_of_orifices D l b relative_hmin Cds Lef hs porosity orifice_height x_length y_length roughness segments slope slope_outlet_channel max_iterations max_fun_eval n_randoms flag_c flag_r hmin s h_end slope_outlet_channel n_channel a_noise b_noise m L Cd_HI u B pperson pfluid h_max_channel L_channel
tic % Startg Counting MPC time

% Disable Warnings
warning('off','all')
warning('query','all')

% Manual Flags - You should enter in the spreadsheet, but if you want to
% change, you must do it here
% flag_c = 0;
% flag_r = 1;
% Control_Horizon = 120;
% Control_Interval = 30;
% Prediction_Horizon = 360;
% max_fun_eval = 50;
% n_randoms = 3;
% number_of_orifices = 1; % Assuming we can control both of them


% Water Quality Parameters
detention_time_max = 12; % hours
detention_time = 0; % Beginning it

% Patter Search Number of Initial Searches
number_of_initials = 5; % Number of initials for pattern search

% a) A few vector calculations
steps_control_horizon = Control_Horizon*60/time_step; % number of steps in the control horizon;
n_controls = Control_Horizon/Control_Interval; % number of controls to choose from an optimization problem
steps_horizon = Prediction_Horizon*60/time_step; % number of steps in one prediction horizon
Qout_w(length(Qout_w):(length(Qout_w)+steps_horizon),1) = 0; % adding more variables to the inflow to account for the last prediction horizon
i_reservoir(length(i_reservoir):(length(i_reservoir)+steps_horizon),1) = 0; % adding more variables to the inflow to account for the last prediction horizon
n_horizons = ceil((n_steps)/(Control_Horizon*60/time_step)); % number of control horizons
Control_Vector = [0:Control_Interval:Prediction_Horizon]*60/time_step;
Nvars = length(Control_Vector);

% b) Objective Function
fun = @Optimization_Function;
OF_value = zeros(n_horizons,1);

% c) Optmizer - Solver
%%%% Interior Point %%%
options = optimoptions(@fmincon,'MaxIterations',max_iterations,'MaxFunctionEvaluations',max_fun_eval); % Previously
%%%% To increase the chances of finding global solutions, we solve the problem
% for n_randoms initial points %%%%

%%%% Estimate random initial points for the Random Search %%%%
matrix = rand(Nvars,n_randoms); % Only for interior points method with fmincon

% Matrices for FMINCON Optimization Problem
A = []; B = []; Aeq = [];Beq = []; Lb = zeros(Nvars,1); Ub = ones(Nvars,1);

%%% Prealocatting Arrays %%%
h_r_final = zeros(n_steps,1);

% h_c_final = zeros(segments,n_steps); too huge, be careful when using
% channel modeling
h_c_max_final = zeros(n_steps,1);
U = zeros(Nvars,1); % Concatenation of future control signals
previous_control = 0;
u = 0; % initial control

% Valve Operations
valve_opening_release = 0.5; % Valve opening for releasing after rainfall (detention control)
valve_opening_static = 0.8; % Static Valve Openess

for i = 1:n_horizons
    perc = i/n_horizons*100;
    perc____timeremainhour = [perc, (toc/60/60)/(perc/100)]

    % Define inflow from the catchment during the prediction horizon
    time_begin = (i-1)*steps_control_horizon + 1; % step
    t_min = time_begin*time_step/60; %  time in min
    time_end = time_begin + steps_horizon;
    t_end = time_end*time_step/60; % final time of the current step
    time_end_saving = time_begin + steps_control_horizon-1; % for saving
    Qout_w_horizon = Qout_w(time_begin:time_end,1); % Result of the Watershed Model
    i_reservoir_horizon = i_reservoir(time_begin:time_end,1); % Result of the Rainfall Forecasting
    
    % Determining random initial points
    %%% Noise Generation - Prediction %%%
    % In case noise is generated in the states, you can model it by a
    % assuming a Gaussian noise with an average and variance specified
    % below
    average = 0.0; % average noise in (m)
    variance = 0; % variance in (m2). Remember that xbar - 2std has a prob of 93... %, std = sqrt(variance)

    %%% - FMINCON WITH RANDOM NUMBERS AS X0
    flag_fmincon = 0; % -1 static with no optimization, 0 patternsearch, 1 fmincon
    if flag_fmincon == 1
        for j=1:n_randoms
            if u(end,1) == 0 % In case the previous control equals zero
                u0 = matrix(:,j); % Random numbers
                u0(1) = U(n_controls);
            else
                u0 = max(U(n_controls)*(a_noise + matrix(:,j)*(b_noise - a_noise)),0); % randomly select values within the adopted range
                u0 = max(u0,0);
                u0(1) = U(n_controls); % the initial estimative is the previous adopted
            end
            if max(Qout_w_horizon) == 0 % If the maximum predicted outflow is zero
                %             U = ur_eq_t*(ones(Nvars,1)); % Here you can either choose to open the valves or close them, in case you want to increase detention time
                detention_time = detention_time + Control_Horizon/60; % hours
                if detention_time > detention_time_max
                    % We start releasing water
                    U = 0.5*(ones(Nvars,1)); % Open 50% only
                else
                    U = 0*(ones(Nvars,1)); % Close Valves and hold water
                end
            else
                detention_time = 0;
                %%% Solving the Optimization Problem for the Random Initial
                %%% Points

                %%%% ------------ Fmincon Solution Use Below ------------------- %%%
                            [U,FVAL] = fmincon(fun,u0',A,B,Aeq,Beq,Lb,Ub,[],options);  % Fmincon solutions
                % ------------------------------------------------------------------------------
                OF(j) = FVAL; % saving the objective function value
                U_random(:,j) = U'; % saving the control vector
                position = find(OF == min(OF)); % position where the minimum value of OF occurs
                if length(position)>1
                    position = position(1);
                end
                % Saving OF value
                U = U_random(:,position); % Chosen control
            end
        end
    elseif flag_fmincon == 0 % Pattern Search Approach
        for j=1:number_of_initials
            %%%%% - Search Algorithms - %%%%
            u0 = zeros(Nvars,1) + (j-1)*(1/(number_of_initials-1));
            if max(Qout_w_horizon) == 0 % If the maximum predicted outflow is zero
                detention_time = detention_time + Control_Horizon/60; % hours
                if detention_time > detention_time_max
                    % We start releasing water
                    U = valve_opening_release*(ones(Nvars,1)); % Open valve_opening_release% only
                else
                    U = 0*(ones(Nvars,1)); % Close Valves and hold water
                end
            else 
                %%%% ------------ Global Search Solution, if you want to use ------------- %%%%
                %             rng default % For reproducibility
                %             ms = MultiStart('FunctionTolerance',2e-4,'UseParallel',true);
                %             gs = GlobalSearch(ms);
                %             gs.MaxTime = 60; % Max time in seconds
                %             gs.NumTrialPoints = 20;
                %             problem = createOptimProblem('fmincon','x0',u0','objective',fun,'lb',Lb,'ub',Ub);
                %             [U,FVAL] = run(gs,problem); % Running global search                
                %%%% --------------- Pattern Search Solution ---------------- %%%%
                [U,FVAL] = patternsearch(fun,u0',A,B,Aeq,Beq,Lb,Ub,[],options); % Pattern search solutions
                OF(j) = FVAL;
                U_random(:,j) = U'; % saving the control vector
                position = find(OF == min(OF)); % position where the minimum value of OF occurs
                if length(position)>1 % More than 1 solution with same O.F
                    position = position(1);
                end
                % Saving OF value
                U = U_random(:,position); % Chosen control
                % ------------------------------------------------------------------------------
            end
        end
    else % Run With Known Valve Control
        U = valve_opening_static*(ones(Nvars,1)); % Here you can either choose to open the valves or close them, in case you want to increase detention time
        FVAL = Optimization_Function(U);
    end
    % Objective Function
    if detention_time > detention_time_max && max(Qout_w_horizon) == 0 % Releasing
        OF_value(i) = nan;
    elseif detention_time <= detention_time_max && max(Qout_w_horizon) == 0 % Holding
        OF_value(i) = nan;
    else % Optimizing
        if flag_fmincon ~= 1 && flag_fmincon ~= 0
            OF_value(i) = FVAL; % Value for known u(k) over time
        else
            OF_value(i) = OF(position); % We are solving the O.P problem
        end
    end

    controls((i-1)*n_controls + 1:i*n_controls,1) = U(1:n_controls)';
    % Implement the Controls in the Plant and retrieving outputs
    %%% Run the Model with the estimated trajectory determined previously %%%
    % Disagregating u into the time-steps of the model
    for j=1:(steps_horizon)
        idx = find(Control_Vector < j,1,'last'); % U disagregated into time-steps
        u(j,1) = U(idx);
    end
    previous_control = U(n_controls);
    %%% Noise Generation - Application %%%
    % In case noise is generated in the states, you can model it by a
    % assuming a Gaussian noise with an average and variance specified
    % below (This applies only to the plant)

    %%% Reservoir Plant %%%
    [h_r,out_r] = plant_reservoir(Qout_w_horizon,time_step,u,g,Cd,number_of_orifices,flag_c,D,flag_r,l,b,hmin,orifice_height,Cds,Lef,hs,porosity,average,variance); % Reservoir Dynamics
    h_r_t = h_r(steps_control_horizon); ur_eq_t = U(n_controls); % Initial values for the next step
    
    %%% Channel Plant %%%
    [max_water_level,h_c,out_c] = plant_channel(out_r,time_step,h_c_0,x_length,y_length,roughness,average,variance,segments,s,slope_outlet_channel,h_end); % Channel Dynamics
    h_c_0 = h_c(:,steps_control_horizon); % Initial Values for the next step
    
    %%% Saving Results %%%
    h_r_final(time_begin:time_end_saving,1) = h_r(1:steps_control_horizon,1);
    out_r_final(time_begin:time_end_saving,1) = out_r(1:steps_control_horizon,1);
    h_c_max_final((time_begin:time_end_saving),1) = max(h_c(:,1:steps_control_horizon))';
    %     h_c_final(:,(time_begin:time_end_saving)) = h_c(:,1:steps_control_horizon);
    out_c_final(time_begin:time_end_saving,1) = out_c(1:steps_control_horizon,1);
end

% Enable Warnigns
warning('on','all')
warning('query','all')

% %% 12.0 Disagregating controls to the time-step unit
Control_Vector = [0:Control_Interval*60/time_step:n_steps];
for i=1:(n_steps-1)
    idx = find(Control_Vector <= i,1,'last'); % Position in U
    u(i,1) = controls(idx);
end
u_begin = 1;
u = [u_begin; u];
% graphs_wshed_reservoir_channel
time_MPC = toc;
display_results_only_reservoir;
