%% Reservoir Dynamics - Main Script
% 4/25/2021
% Developer: Marcus Nobrega
% Goal - Develop a linearized state-space represenntation of the Reservoir
% Plant
function [x_r,out_r] = reservoir_dynamics(Qout_w,time_step,u,g,Cd,number_of_orifices,flag_c,D,flag_r,l,b,hmin,orifice_height,Cds,Lef,hs,porosity,average,variance)
global Qout_w Qout_w_horizon steps_control_horizon steps_horizon time_step n_steps Control_Vector Nvars i_reservoir h_c_0 h_r_t ur_eq_t i_reservoir_horizon previous_control average variance slope_outlet tfinal record_time_maps ETP new_timestep Control_Interval Control_Horizon Prediction_Horizon g Cd flag_r number_of_orifices D l b relative_hmin Cds Lef hs porosity orifice_height x_length y_length roughness segments slope slope_outlet_channel max_iterations max_fun_eval n_randoms flag_c flag_r hmin s h_end slope_outlet_channel n_channel
%% Parameters
% Equilibrium Points
h_eq = h_r_t; % m
% Initial Values
u_eq = ur_eq_t; % boolean (0-1), 1 is fully opened, 0 is fully closed
T = time_step; % seconds
% Reservoir Area
[~,Area,~,~] = reservoir_area(h_eq,0); % A = f(h,flag_volume) (handle) Function. If flag_volume == 1, we don't integrate vol functions and it is faster
Aoc = pi()*D^2/4*number_of_orifices;
Aor = l*b*number_of_orifices;
if ((flag_c == 1) && (flag_r == 1)) 
    error('Please choose only one type of orifice')
elseif (flag_c == 1)    
    D_h = D; % circular
    Ao = Aoc;
else
    D_h = 4*(l*b)/(2*(l+b)); % rectangular
    Ao = Aor;
end
h_flow = (hmin*D_h + orifice_height); % Depth to start the orifice outflow
% Inflow
Qin = Qout_w_horizon; % m3/s
% Flow Equation
outflow_eq = @(Ko,Ks,h,hs,ho,u_eq) (Ko.*u_eq.*sqrt(max(h - h_flow,0)) + max(Ks.*(h - hs),0).^(3/2));
%% Calculating Constants
Ko = Cd*Ao*sqrt(2*g); Ks = Cds*Lef; 
%% Symbolic Alfa and Beta Matrices
[alfa_1_function,alfa_2_function,beta_1_function,beta_2_function] = symbolic_jacobians(); % 
%% Determining Jacobian Matrices
Qin_t = Qin(1);
i_0 = i_reservoir_horizon(1,1); 
[alfa,beta] = alfabeta_matrices(Qin_t,Ko,u_eq,h_eq,h_flow,Ks,hs,h_r_t,alfa_1_function,alfa_2_function,beta_1_function,beta_2_function,D_h);   
gama = (1/(Area*porosity)*(Qin_t - outflow_eq(Ko,Ks,h_eq,hs,h_flow,u_eq))) + i_0/1000/3600; % Adding Rainfall - Evaporation
gama(isnan(gama))=0; % Cases where the area might be equals 0
%% Discretizing the System - Foward Euler
A = (1 + T*alfa);
B = (T*beta);
fi = (T*gama - T*alfa*h_eq - T*beta*u_eq);
% h(k+1) = A*h(k) + B*u + fi(k)
h = zeros(steps_horizon,1); 
out_r = zeros(steps_horizon,1);
h(1,1) = h_r_t;
x_r = h;
%% Flow Routing - Main for loop
for k = 1:(steps_horizon-1)    
    if k == 6842
        ttt = 1;
    end
    % Generate a Gaussian Noise
    [g_noise] = gaussian_noise_generator(variance,average);
    h(k+1) = max(A*h(k) + B*u(k,1) + fi + g_noise ,0); % Constraint to make water level positive
    x_r(k+1) = h(k+1);
    Qin_t = Qin(k+1);
    i_0 = i_reservoir_horizon(k,1); % Initial Rainfall for the next time-step
    h_t = h(k);
    % New Operation Point
    h_eq = h(k);
    u_eq = u(k);
    % Outflow
    out_r(k,1) = outflow_eq(Ko,Ks,h_eq,hs,h_flow,u_eq);
    % Jacobians
    if isinf(h_t) || isnan(h_t)
        error('Inf Depths or Nan Depths')
    end
    [alfa,beta] = alfabeta_matrices(Qin_t,Ko,u_eq,h_eq,h_flow,Ks,hs,h_t,alfa_1_function,alfa_2_function,beta_1_function,beta_2_function,D_h);   
    [~,Area,~,~] = reservoir_area(h_eq,0); % A = f(h,flag_volume) (handle) Function. If flag_volume == 1, we don't integrate vol functions and it is faster
    gama = (1/(Area*porosity)*(Qin_t - out_r(k,1))) + i_0/1000/3600;
    gama(isnan(gama))=0;
    % New State-Space
    A = (1 + T*alfa);
    B = (T*beta);
    fi = (T*gama - T*alfa*h_eq - T*beta*u_eq);
end
x_r = h;